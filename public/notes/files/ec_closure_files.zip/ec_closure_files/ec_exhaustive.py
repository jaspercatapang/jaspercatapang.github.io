#!/usr/bin/env python3
"""
ec_exhaustive.py

Exhaustive check of the block lemma (Lemma 1), Corollary 1 and the block
construction of Theorem 1 on EVERY paired tree with at most MAX_LEAVES leaves,
every arity >= 2 and every permutation at every node.

Companion to "A remark on code-switching under the Equivalence Constraint".
Independent of the Lean development: everything on the "definition" side is
computed from prefix sets (Definitions 2-3), everything on the "construction"
side from the permutations alone.

Usage:  python3 ec_exhaustive.py [MAX_LEAVES]      (default 7)

A tree is either
    ("leaf", k)                 k = leaf id, numbered in language-1 order
    ("node", pi, children)      children in language-1 order;
                                pi[p] = language-1 index of the child that
                                stands in position p in language 2 (0-based)
"""
import sys
from itertools import permutations, product
from functools import lru_cache


# ---------------------------------------------------------------- enumeration

def compositions(n, k):
    """Ordered k-tuples of positive integers summing to n."""
    if k == 1:
        yield (n,)
        return
    for first in range(1, n - k + 2):
        for rest in compositions(n - first, k - 1):
            yield (first,) + rest


@lru_cache(maxsize=None)
def shapes(n):
    """All trees with n leaves (leaf ids not yet assigned), arity >= 2."""
    if n == 1:
        return (("leaf", None),)
    out = []
    for k in range(2, n + 1):
        perms = list(permutations(range(k)))
        for comp in compositions(n, k):
            for kids in product(*(shapes(c) for c in comp)):
                for pi in perms:
                    out.append(("node", pi, kids))
    return tuple(out)


def number(t, counter=None):
    """Assign leaf ids 0,1,2,... in language-1 order."""
    if counter is None:
        counter = [0]
    if t[0] == "leaf":
        k = counter[0]
        counter[0] += 1
        return ("leaf", k)
    return ("node", t[1], tuple(number(c, counter) for c in t[2]))


# ----------------------------------------------------- definitions (prefix sets)

def lin1(t):
    if t[0] == "leaf":
        return [t[1]]
    return [x for c in t[2] for x in lin1(c)]


def lin2(t):
    if t[0] == "leaf":
        return [t[1]]
    return [x for p in t[1] for x in lin2(t[2][p])]


def eq_points(l1, l2):
    """Definition 2: cuts j with P1(j) = P2(j)."""
    return [j for j in range(len(l1) + 1) if set(l1[:j]) == set(l2[:j])]


def realizations_def(l1, l2):
    """Definition 3: one language per stretch between consecutive eq. points."""
    ep = eq_points(l1, l2)
    pieces = []
    for a, b in zip(ep, ep[1:]):
        pieces.append((tuple((1, x) for x in l1[a:b]), tuple((2, x) for x in l2[a:b])))
    out = set()
    for choice in product((0, 1), repeat=len(pieces)):
        s = ()
        for pc, c in zip(pieces, choice):
            s += pc[c]
        out.add(s)
    return out


# --------------------------------------------- construction (permutations only)

def boundaries(pi):
    """Left-to-right scan: i is a boundary iff max(pi[0..i-1]) = i-1."""
    out = [0]
    mx = -1
    for i, v in enumerate(pi, start=1):
        mx = max(mx, v)
        if mx == i - 1:
            out.append(i)
    return out


def boundaries_def(pi):
    """Definition 4: i is a boundary iff {pi[0..i-1]} = {0..i-1}."""
    return [i for i in range(len(pi) + 1) if set(pi[:i]) == set(range(i))]


def blocks(pi):
    b = boundaries(pi)
    return [list(range(x, y)) for x, y in zip(b, b[1:])]


def mono(t, lang):
    l = lin1(t) if lang == 1 else lin2(t)
    return tuple((lang, x) for x in l)


def gen_E(t):
    """Sentences derived from A^E in G_EC, read off the tree."""
    if t[0] == "leaf":
        return {((1, t[1]),), ((2, t[1]),)}
    pi, kids = t[1], t[2]
    parts = []
    for blk in blocks(pi):
        if len(blk) == 1:
            parts.append(gen_E(kids[blk[0]]))
        else:
            one = sum((mono(kids[i], 1) for i in blk), ())
            two = sum((mono(kids[pi[p]], 2) for p in blk), ())
            parts.append({one, two})
    out = {()}
    for part in parts:
        out = {s + x for s in out for x in part}
    return out


# ------------------------------------------------------------------- the checks

def nodes(t, path=()):
    yield path, t
    if t[0] == "node":
        for i, c in enumerate(t[2]):
            yield from nodes(c, path + (i,))


def check_tree(t, max_pieces=None):
    l1, l2 = lin1(t), lin2(t)
    n = len(l1)
    pos1 = {x: i for i, x in enumerate(l1)}
    pos2 = {x: i for i, x in enumerate(l2)}
    ep = set(eq_points(l1, l2))
    assert 0 in ep and n in ep

    info = {}
    for path, v in nodes(t):
        Y = set(lin1(v))
        s1 = min(pos1[x] for x in Y)
        s2 = min(pos2[x] for x in Y)
        # yields are contiguous in both orders
        assert {pos1[x] for x in Y} == set(range(s1, s1 + len(Y)))
        assert {pos2[x] for x in Y} == set(range(s2, s2 + len(Y)))
        pre1, pre2 = set(l1[:s1]), set(l2[:s2])
        info[path] = (v, Y, s1, pre1 == pre2)

    aligned = {p for p, x in info.items() if x[3]}

    # (a) the root is aligned; an aligned node has an aligned parent
    assert () in aligned
    for p in aligned:
        if p:
            assert p[:-1] in aligned

    # (b) an equivalence point that splits Y(v) forces v aligned
    for j in ep:
        P = set(l1[:j])
        for p, (v, Y, s1, al) in info.items():
            if Y & P and Y - P:
                assert al

    # an aligned node has equivalence points at both ends of its yield
    for p in aligned:
        v, Y, s1, _ = info[p]
        assert s1 in ep and s1 + len(Y) in ep

    # (c) at an aligned node: cuts between children vs. boundaries;
    #     aligned children vs. singleton blocks
    ep_from_blocks = {0, n}
    pieces_from_blocks = set()
    for p in aligned:
        v, Y, s1, _ = info[p]
        if v[0] == "leaf":
            pieces_from_blocks.add((s1, s1 + 1))
            continue
        pi, kids = v[1], v[2]
        assert boundaries(pi) == boundaries_def(pi)
        bnd = set(boundaries(pi))
        cut = s1
        cuts = [cut]
        for c in kids:
            cut += len(lin1(c))
            cuts.append(cut)
        for i, c in enumerate(cuts):
            assert (c in ep) == (i in bnd)
            if i in bnd:
                ep_from_blocks.add(c)
        singles = {blk[0] for blk in blocks(pi) if len(blk) == 1}
        for i in range(len(kids)):
            assert ((p + (i,)) in aligned) == (i in singles)
            if i in singles:
                assert pi[i] == i
        for blk in blocks(pi):
            if len(blk) > 1:
                pieces_from_blocks.add((cuts[blk[0]], cuts[blk[-1] + 1]))

    # (d) EP(t) = block boundaries of the aligned nodes;
    #     aligned nodes = those reached through singleton blocks only
    assert ep == ep_from_blocks
    reach = set()
    stack = [()]
    while stack:
        p = stack.pop()
        reach.add(p)
        v = info[p][0]
        if v[0] == "node":
            for blk in blocks(v[1]):
                if len(blk) == 1:
                    stack.append(p + (blk[0],))
    assert reach == aligned

    # Corollary 1: the stretches between consecutive equivalence points are the
    # aligned leaves and the non-singleton blocks of aligned nodes
    eps = sorted(ep)
    assert set(zip(eps, eps[1:])) == pieces_from_blocks

    # Corollary 2 (switchability), read from the cut upwards
    for j in range(1, n):
        p = ()
        ok = True
        while True:
            v, Y, s1, _ = info[p]
            pi, kids = v[1], v[2]
            cut = s1
            inside = None
            at_boundary = None
            for i, c in enumerate(kids):
                nxt = cut + len(lin1(c))
                if cut < j < nxt:
                    inside = i
                    break
                if nxt == j:
                    at_boundary = i + 1
                    break
                cut = nxt
            if inside is None:
                ok = ok and (at_boundary in boundaries(pi))
                break
            if [inside] not in blocks(pi):
                ok = False
                break
            p = p + (inside,)
        assert ok == (j in ep)

    # block construction (Theorem 1 on this tree): 2^(number of pieces) sentences
    if max_pieces is None or len(eps) - 1 <= max_pieces:
        assert gen_E(t) == realizations_def(l1, l2)
        return True
    return False


def main():
    max_leaves = int(sys.argv[1]) if len(sys.argv) > 1 else 7
    total = 0
    for n in range(1, max_leaves + 1):
        cnt = 0
        for sh in shapes(n):
            check_tree(number(sh))
            cnt += 1
        total += cnt
        print(f"  {n} leaves: {cnt:>7} trees  ok", flush=True)
    print(f"all checks passed on {total} trees (every tree with at most "
          f"{max_leaves} leaves, arity >= 2, every permutation at every node)")


if __name__ == "__main__":
    main()
