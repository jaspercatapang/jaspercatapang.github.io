#!/usr/bin/env python3
"""
ec_grammar_test.py

End-to-end test of Theorem 1 on random congruent grammar pairs.

For each pair (G1, G2, h):
  * build G_EC exactly as in the proof of Theorem 1, with the blocks of every
    permutation computed by the left-to-right scan of Section 5;
  * enumerate L(G_EC) up to a length bound with a generic context-free
    enumerator that knows nothing about trees or blocks;
  * compute L_EC up to the same bound from the definition: enumerate the
    derivation trees of the pair, find the equivalence points of each tree
    from prefix sets (Definition 2), and take all realizations (Definition 3);
  * compare the two sets.

Companion to "A remark on code-switching under the Equivalence Constraint".
Independent of the Lean development.

Usage:  python3 ec_grammar_test.py [PAIRS] [MAX_LEN] [SEED]
        (defaults 150, 5, 20261121)

A grammar pair is a list of rules over nonterminals 0..k-1 (start symbol 0):
    ("lex", A, w1, w2)          A -> w1  /  A -> w2
    ("struct", A, rhs, pi)      A -> rhs[0] ... rhs[m-1]            (language 1)
                                A -> rhs[pi[0]] ... rhs[pi[m-1]]    (language 2)
"""
import random
import sys
from itertools import product


# ------------------------------------------------------------ random grammars

def random_perm(rng, m):
    r = rng.random()
    if r < 0.25:
        return tuple(range(m))
    if r < 0.60:
        p = list(range(m))
        rng.shuffle(p)
        return tuple(p)
    out, i = [], 0
    while i < m:
        size = rng.randint(1, m - i)
        blk = list(range(i, i + size))
        rng.shuffle(blk)
        out.extend(blk)
        i += size
    return tuple(out)


def random_pair(rng):
    k = rng.randint(2, 4)                       # nonterminals 0..k-1
    v = rng.randint(2, 4)                       # words per language
    rules = []
    for A in range(k):                          # every nonterminal is productive
        for _ in range(rng.randint(1, 2)):
            rules.append(("lex", A, f"a{rng.randrange(v)}", f"b{rng.randrange(v)}"))
    for _ in range(rng.randint(2, 5)):
        A = rng.randrange(k)
        m = rng.choice([1, 2, 2, 2, 3, 3, 4])
        if m == 1:
            if A == k - 1:
                continue
            rhs = (rng.randrange(A + 1, k),)    # unary rules only go upwards: no cycles
        else:
            rhs = tuple(rng.randrange(k) for _ in range(m))   # repeats allowed
        rules.append(("struct", A, rhs, random_perm(rng, m)))
    rules = list(dict.fromkeys(rules))          # drop exact duplicates
    return rules


# -------------------------------------------- G_EC, as in the proof of Theorem 1

def blocks(pi):
    """Left-to-right scan: i is a boundary iff max(pi[0..i-1]) = i-1."""
    bnd, mx = [0], -1
    for i, x in enumerate(pi, start=1):
        mx = max(mx, x)
        if mx == i - 1:
            bnd.append(i)
    return [list(range(a, b)) for a, b in zip(bnd, bnd[1:])]


def build_gec(rules):
    """Rules of G_EC as (lhs, rhs) with nonterminals as tuples and words as str."""
    out = []
    for ridx, r in enumerate(rules):
        if r[0] == "lex":
            _, A, w1, w2 = r
            out += [((1, A), (w1,)), ((2, A), (w2,)), (("E", A), (w1,)), (("E", A), (w2,))]
            continue
        _, A, rhs, pi = r
        m = len(rhs)
        out.append(((1, A), tuple((1, rhs[i]) for i in range(m))))
        out.append(((2, A), tuple((2, rhs[pi[p]]) for p in range(m))))
        aligned = []
        for bidx, blk in enumerate(blocks(pi)):
            if len(blk) == 1:
                aligned.append(("E", rhs[blk[0]]))
            else:
                Z = ("Z", ridx, bidx)           # fresh nonterminal
                aligned.append(Z)
                out.append((Z, tuple((1, rhs[i]) for i in blk)))
                out.append((Z, tuple((2, rhs[pi[p]]) for p in blk)))
        out.append((("E", A), tuple(aligned)))
    return out


# ------------------------------------------- generic context-free enumerator

def cfg_language(cfg_rules, start, max_len):
    """All terminal strings of length <= max_len derivable from `start`.
    Plain fixpoint over (nonterminal -> set of strings); terminals are str."""
    lang = {}
    for lhs, _ in cfg_rules:
        lang.setdefault(lhs, set())
    changed = True
    while changed:
        changed = False
        for lhs, rhs in cfg_rules:
            partial = {()}
            for symb in rhs:
                opts = {(symb,)} if isinstance(symb, str) else lang.get(symb, set())
                partial = {s + o for s in partial for o in opts if len(s) + len(o) <= max_len}
                if not partial:
                    break
            new = partial - lang[lhs]
            if new:
                lang[lhs] |= new
                changed = True
    return lang.get(start, set())


def mono_grammar(rules, which):
    out = []
    for r in rules:
        if r[0] == "lex":
            out.append((("N", r[1]), (r[2 if which == 1 else 3],)))
        else:
            _, A, rhs, pi = r
            order = range(len(rhs)) if which == 1 else pi
            out.append((("N", A), tuple(("N", rhs[i]) for i in order)))
    return out


# ----------------------------------------------- L_EC from the definition

def compositions(n, k):
    if k == 1:
        yield (n,)
        return
    for first in range(1, n - k + 2):
        for rest in compositions(n - first, k - 1):
            yield (first,) + rest


def derivation_trees(rules, max_len):
    """trees[A][n] = all derivation trees rooted in A with exactly n leaves."""
    k = 1 + max(r[1] for r in rules)
    trees = {A: {n: [] for n in range(1, max_len + 1)} for A in range(k)}
    for n in range(1, max_len + 1):
        # unary rules point to larger nonterminals, so go from large A to small A
        for A in reversed(range(k)):
            for r in rules:
                if r[1] != A:
                    continue
                if r[0] == "lex":
                    if n == 1:
                        trees[A][n].append(("leaf", r[2], r[3]))
                    continue
                _, _, rhs, pi = r
                m = len(rhs)
                if m > n:
                    continue
                for comp in compositions(n, m):
                    for kids in product(*(trees[rhs[i]][comp[i]] for i in range(m))):
                        trees[A][n].append(("node", pi, kids))
    return trees


def linearize(t):
    """(lin1, lin2) as lists of leaves (id, w1, w2); ids make the leaves distinct."""
    counter = [0]

    def go(t):
        if t[0] == "leaf":
            leaf = (counter[0], t[1], t[2])
            counter[0] += 1
            return [leaf], [leaf]
        pi, kids = t[1], t[2]
        parts = [go(c) for c in kids]
        l1 = [x for p in parts for x in p[0]]
        l2 = [x for q in pi for x in parts[q][1]]
        return l1, l2

    return go(t)


def realizations(t):
    """Definitions 2-3 on one tree."""
    l1, l2 = linearize(t)
    n = len(l1)
    ep = [j for j in range(n + 1) if {x[0] for x in l1[:j]} == {x[0] for x in l2[:j]}]
    pieces = [(tuple(x[1] for x in l1[a:b]), tuple(x[2] for x in l2[a:b]))
              for a, b in zip(ep, ep[1:])]
    out = set()
    for choice in product((0, 1), repeat=len(pieces)):
        s = ()
        for pc, c in zip(pieces, choice):
            s += pc[c]
        out.add(s)
    return out


def lec_language(rules, start, max_len):
    trees = derivation_trees(rules, max_len)
    out = set()
    ntrees = 0
    for n in range(1, max_len + 1):
        for t in trees[start][n]:
            ntrees += 1
            out |= realizations(t)
    return out, ntrees


# ------------------------------------------------------------------------ main

def is_mixed(s):
    return any(w[0] == "a" for w in s) and any(w[0] == "b" for w in s)


def main():
    pairs = int(sys.argv[1]) if len(sys.argv) > 1 else 150
    max_len = int(sys.argv[2]) if len(sys.argv) > 2 else 5
    seed = int(sys.argv[3]) if len(sys.argv) > 3 else 20261121
    rng = random.Random(seed)

    tot_sent = tot_mixed = tot_trees = with_switch = 0
    for idx in range(pairs):
        rules = random_pair(rng)
        gec = build_gec(rules)
        from_grammar = cfg_language(gec, ("E", 0), max_len)
        from_definition, ntrees = lec_language(rules, 0, max_len)
        if from_grammar != from_definition:
            print(f"MISMATCH on pair {idx}")
            for r in rules:
                print("   ", r)
            print("  only in L(G_EC):", sorted(from_grammar - from_definition)[:5])
            print("  only in L_EC:   ", sorted(from_definition - from_grammar)[:5])
            sys.exit(1)
        # L(G1) ∪ L(G2) ⊆ L_EC, and the purely monolingual sentences are exactly those
        l1 = cfg_language(mono_grammar(rules, 1), ("N", 0), max_len)
        l2 = cfg_language(mono_grammar(rules, 2), ("N", 0), max_len)
        assert l1 | l2 <= from_definition
        assert {s for s in from_definition if not is_mixed(s)} == l1 | l2
        mixed = sum(1 for s in from_definition if is_mixed(s))
        tot_sent += len(from_definition)
        tot_mixed += mixed
        tot_trees += ntrees
        with_switch += mixed > 0

    print(f"L(G_EC) = L_EC up to length {max_len} on all {pairs} random grammar pairs "
          f"(seed {seed})")
    print(f"  derivation trees enumerated: {tot_trees}")
    print(f"  sentences compared:          {tot_sent}")
    print(f"  of which mix both languages: {tot_mixed}  ({with_switch} pairs allow a switch)")


if __name__ == "__main__":
    main()
