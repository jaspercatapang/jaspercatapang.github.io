#!/usr/bin/env python3
"""
ec_check.py

Randomized check of the block lemma (Lemma 1), Corollaries 1-2 and the block
construction of Theorem 1 on larger paired trees than ec_exhaustive.py can
enumerate: 8 to 25 leaves, arities 1 to 6 (unary nodes included), with
permutations drawn so that deep aligned nodes, large blocks and nested blocks
all occur.

Companion to "A remark on code-switching under the Equivalence Constraint".
The checks themselves are those of ec_exhaustive.py (same directory).

Usage:  python3 ec_check.py [TREES_PER_SIZE] [SEED]     (defaults 700, 20261121)
"""
import random
import sys

from ec_exhaustive import check_tree, number

MIN_LEAVES, MAX_LEAVES = 8, 25
MAX_PIECES = 14          # compare full sentence sets up to 2^14 sentences


def random_perm(rng, k):
    """Identity, a full shuffle, or a shuffle inside random consecutive blocks."""
    r = rng.random()
    if r < 0.30:
        return tuple(range(k))
    if r < 0.55:
        p = list(range(k))
        rng.shuffle(p)
        return tuple(p)
    out, i = [], 0
    while i < k:
        size = rng.randint(1, k - i)
        blk = list(range(i, i + size))
        rng.shuffle(blk)
        out.extend(blk)
        i += size
    return tuple(out)


def random_tree(rng, n, unary_budget=2):
    if n == 1 and (unary_budget == 0 or rng.random() < 0.85):
        return ("leaf", None)
    if unary_budget > 0 and rng.random() < 0.08:
        return ("node", (0,), (random_tree(rng, n, unary_budget - 1),))
    if n == 1:
        return ("leaf", None)
    k = rng.randint(2, min(n, 6))
    cuts = sorted(rng.sample(range(1, n), k - 1))
    sizes = [b - a for a, b in zip([0] + cuts, cuts + [n])]
    kids = tuple(random_tree(rng, s, unary_budget) for s in sizes)
    return ("node", random_perm(rng, k), kids)


def main():
    per_size = int(sys.argv[1]) if len(sys.argv) > 1 else 700
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 20261121
    rng = random.Random(seed)
    total = full = 0
    for n in range(MIN_LEAVES, MAX_LEAVES + 1):
        for _ in range(per_size):
            t = number(random_tree(rng, n))
            if check_tree(t, max_pieces=MAX_PIECES):
                full += 1
            total += 1
    print(f"all checks passed on {total} random trees with {MIN_LEAVES}-{MAX_LEAVES} "
          f"leaves (seed {seed})")
    print(f"  Lemma 1, Corollaries 1-2: all {total} trees")
    print(f"  full sentence sets compared (at most 2^{MAX_PIECES} sentences): {full} trees")


if __name__ == "__main__":
    main()
