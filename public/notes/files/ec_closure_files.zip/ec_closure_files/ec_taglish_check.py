#!/usr/bin/env python3
"""
ec_taglish_check.py

Checks the "alignment" column of Example 2 (the Tagalog-English fragment) in
"A remark on code-switching under the Equivalence Constraint": membership of
each example sentence in L_EC, computed from the prefix-set definition by
ec_grammar_test.py (same directory), and agreement of L_EC with L(G_EC) on the
fragment up to length 6.

Usage:  python3 ec_taglish_check.py
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ec_grammar_test import lec_language, build_gec, cfg_language, mono_grammar
S,NPa,NPn,Vt,Vi,Vc,CP,C,Ka,Kn,A,N,Pro = range(13)
def lex(c, e, t): return ("lex", c, e, t)
LEX = [lex(Ka,"the","ang"), lex(Kn,"a","ng"), lex(Pro,"I","ako"), lex(Pro,"he","siya"),
       lex(Vt,"bought","bumili"), lex(Vc,"said","nagsabi"), lex(Vi,"left","umalis"),
       lex(C,"that","na"), lex(A,"new","bagong"),
       lex(N,"book","libro"), lex(N,"teacher","guro"), lex(N,"phone","telepono")]
def gram(r1perm, pro=True):
    R = [("struct", S, (NPa,Vt,NPn), r1perm),
         ("struct", S, (NPa,Vi), (1,0)),
         ("struct", S, (NPa,Vc,CP), (1,0,2)),
         ("struct", CP, (C,S), (0,1)),
         ("struct", NPa, (Ka,N), (0,1)), ("struct", NPn, (Kn,N), (0,1)),
         ("struct", NPa, (Ka,A,N), (0,1,2)), ("struct", NPn, (Kn,A,N), (0,1,2))]
    if pro: R.append(("struct", NPa, (Pro,), (0,)))
    return R + LEX
tests = {
 "r1": [("bumili ako ng new phone",True),("bumili ako ng bagong phone",True),
        ("bumili ako ng phone",True),
        ("nagsabi siya na he left",True),("bumili ang teacher ng libro",False),
        ("nagsabi siya na umalis ang teacher",False),("nagsabi siya na umalis the teacher",False),
        ("bumili ako a new phone",True),
        ("bumili ang guro ng libro",True),("the teacher bought a book",True),
        ("nagsabi siya na umalis ang guro",True),("he said that the teacher left",True)],
 "r1'": [("bumili ng libro ang teacher",False),("bumili ng libro ang guro",True),("bumili ng book ang guro",False)],
}
for name, perm, pro in (("r1",(1,0,2),True),("r1'",(1,2,0),False)):
    G = gram(perm, pro)
    lec, ntrees = lec_language(G, S, 6)
    gec = cfg_language(build_gec(G), ("E", S), 6)
    print(name, "trees", ntrees, "|L_EC|", len(lec), "G_EC agrees:", lec == gec)
    for s, want in tests[name]:
        got = tuple(s.split()) in lec
        print("  %-42s in L_EC: %-5s %s" % (s, got, "ok" if got == want else "MISMATCH"))
