/-
  ECClosure.lean

  Code-switching under the Equivalence Constraint (alignment reading) is
  context-free.

  Companion to: J. K. Catapang, "A remark on code-switching under the
  Equivalence Constraint" (21 November 2026).

  Lean 4 (checked with 4.36.0), core library only, no Mathlib.
  To re-check:   lean ECClosure.lean
  No `sorry`; the theorems depend only on propext, Classical.choice, Quot.sound
  (printed by the `#print axioms` lines at the end).

  Contents
  --------
  Part 0   list lemmas missing from the core library
  Part I   trees
             EqPt, RealEP         equivalence point; realization (Definitions 2-3)
             Real                 realization, chunk form (Remark 2)
             realEP_iff_real      the two forms agree
             Irr, Blocks          block of a permutation
             Real.split           a realization splits at any equivalence point
             no_cut_inside,
             irr_flat             no equivalence point inside a non-singleton block
             node_theorem         Lemma 1 and Corollary 1 at one node
             main_theorem,
             main_theorem_EP      tree-level theorem
             swapClause_gram      Example 1
  Part II  grammars
             CFG, CFG.Gen, CFG.Language
             PRule, WFG           congruent pair of grammars (Definition 1)
             DTree, DTree.Valid   derivation tree of the pair
             LEC                  the language L_EC
             NT, rulesOf, gec     the grammar G_EC
             gec_complete         L_EC ⊆ L(G_EC)
             gec_sound            L(G_EC) ⊆ L_EC
             gec_correct          Theorem 1:  L(G_EC) = L_EC
             LEC_contextFree      L_EC is context-free
             mono_subset          L(G_1) ∪ L(G_2) ⊆ L_EC
-/

set_option autoImplicit false

/-! # Part 0: list lemmas -/

/-- Two lists related elementwise (the core library has no `Forall₂`). -/
inductive All2 {α β : Type} (R : α → β → Prop) : List α → List β → Prop
  | nil : All2 R [] []
  | cons {a : α} {b : β} {l : List α} {l' : List β} :
      R a b → All2 R l l' → All2 R (a :: l) (b :: l')

namespace All2

variable {α β γ : Type} {R S : α → β → Prop}

theorem imp_mem {l : List α} {l' : List β} (h : All2 R l l')
    (hRS : ∀ a b, a ∈ l → R a b → S a b) : All2 S l l' := by
  induction h with
  | nil => exact .nil
  | cons hab _ ih =>
    exact .cons (hRS _ _ (List.mem_cons_self) hab)
      (ih (fun a b ha => hRS a b (List.mem_cons_of_mem _ ha)))

theorem imp {l : List α} {l' : List β} (h : All2 R l l')
    (hRS : ∀ a b, R a b → S a b) : All2 S l l' :=
  h.imp_mem (fun a b _ => hRS a b)

theorem map_left {f : γ → α} {l : List γ} {l' : List β} :
    All2 R (l.map f) l' ↔ All2 (fun c b => R (f c) b) l l' := by
  constructor
  · intro h
    induction l generalizing l' with
    | nil => cases h; exact .nil
    | cons c l ih =>
      cases h with
      | cons hab ht => exact .cons hab (ih ht)
  · intro h
    induction h with
    | nil => exact .nil
    | cons hab _ ih => exact .cons hab ih

/-- Every element on the left is related to something. -/
theorem exists_of_mem {l : List α} {l' : List β} (h : All2 R l l') :
    ∀ a, a ∈ l → ∃ b, R a b := by
  induction h with
  | nil => intro a ha; cases ha
  | cons hab _ ih =>
    intro a ha
    rcases List.mem_cons.mp ha with rfl | ha
    · exact ⟨_, hab⟩
    · exact ih a ha

theorem eq_map {g : α → β} {l : List α} {l' : List β}
    (h : All2 (fun a b => b = g a) l l') : l' = l.map g := by
  induction h with
  | nil => rfl
  | cons hab _ ih => simp [hab, ih]

end All2

theorem exists_least (p : Nat → Prop) (n : Nat) (h : p n) :
    ∃ k, p k ∧ ∀ i, i < k → ¬ p i := by
  induction n using Nat.strongRecOn with
  | _ n ih =>
    by_cases hex : ∃ i, i < n ∧ p i
    · obtain ⟨i, hi, hpi⟩ := hex
      exact ih i hi hpi
    · exact ⟨n, h, fun i hi hpi => hex ⟨i, hi, hpi⟩⟩

theorem append_split {α : Type} {s t s' t' : List α} (h : s ++ t = s' ++ t')
    (hl : s.length ≤ s'.length) : ∃ r, s' = s ++ r ∧ t = r ++ t' := by
  rcases List.append_eq_append_iff.mp h with ⟨as, h1, h2⟩ | ⟨bs, h1, h2⟩
  · exact ⟨as, h1, h2⟩
  · have hb : bs = [] := by
      have := congrArg List.length h1
      simp at this
      exact List.eq_nil_of_length_eq_zero (by omega)
    subst hb
    refine ⟨[], ?_, ?_⟩
    · simpa using h1.symm
    · simpa using h2.symm

theorem perm_cancel_left {α : Type} {x y a b : List α} (h : x.Perm y)
    (h' : (x ++ a).Perm (y ++ b)) : a.Perm b :=
  (List.perm_append_left_iff y).mp ((h.symm.append_right a).trans h')

theorem perm_flatMap {α : Type} {u v : Nat → List α} {I J : List Nat} (hIJ : I.Perm J)
    (h : ∀ i, i ∈ I → (u i).Perm (v i)) : (I.flatMap u).Perm (J.flatMap v) := by
  have h1 : (I.flatMap u).Perm (I.flatMap v) := by
    clear hIJ
    induction I with
    | nil => simp
    | cons i I ih =>
      simp only [List.flatMap_cons]
      exact (h i List.mem_cons_self).append (ih (fun j hj => h j (List.mem_cons_of_mem _ hj)))
  exact h1.trans (List.Perm.flatMap_right v hIJ)

/-- `take` across a known decomposition of `drop`. -/
theorem take_seg {α : Type} {l c d : List α} {j : Nat} (h : l.drop j = c ++ d) :
    l.take (j + c.length) = l.take j ++ c := by
  rw [List.take_add, h, List.take_left' rfl]

/-- The stretch of `l` between cuts `j` and `j'`. -/
def seg {α : Type} (l : List α) (j j' : Nat) : List α := (l.drop j).take (j' - j)

theorem drop_eq_seg_append {α : Type} (l : List α) {j j' : Nat} (h : j ≤ j') :
    l.drop j = seg l j j' ++ l.drop j' := by
  have := (List.take_append_drop (j' - j) (l.drop j)).symm
  rw [List.drop_drop] at this
  have e : j + (j' - j) = j' := by omega
  rw [e] at this
  exact this

theorem take_eq_take_append_seg {α : Type} (l : List α) {j j' : Nat} (h : j ≤ j') :
    l.take j' = l.take j ++ seg l j j' := by
  have e : j' = j + (j' - j) := by omega
  conv => lhs; rw [e, List.take_add]
  rfl

theorem seg_length {α : Type} (l : List α) {j j' : Nat} (h : j ≤ j') (h' : j' ≤ l.length) :
    (seg l j j').length = j' - j := by
  simp [seg]; omega

/-! # Part I: trees -/

/-- A leaf is a position in the tree (its address) carrying one word in each language. -/
structure Leaf (T : Type) where
  addr : List Nat
  w1 : T
  w2 : T

/-- A paired tree.  `node m π cs` has children `cs 0, …, cs (m-1)` in language-1 order and
`cs π[0], …, cs π[m-1]` in language-2 order.  (Values `cs i` for `i ≥ m` are ignored.) -/
inductive Tree (T : Type) where
  | leaf (a b : T) : Tree T
  | node (m : Nat) (π : List Nat) (cs : Nat → Tree T) : Tree T

namespace Tree

variable {T : Type}

/-- Leaves in language-1 order; `p` is the address of the root. -/
def lin1 : Tree T → List Nat → List (Leaf T)
  | .leaf a b, p => [⟨p, a, b⟩]
  | .node m _ cs, p => (List.range m).flatMap fun i => (cs i).lin1 (p ++ [i])

/-- Leaves in language-2 order. -/
def lin2 : Tree T → List Nat → List (Leaf T)
  | .leaf a b, p => [⟨p, a, b⟩]
  | .node _ π cs, p => π.flatMap fun i => (cs i).lin2 (p ++ [i])

/-- The language-1 sentence of the tree. -/
def y1 : Tree T → List T
  | .leaf a _ => [a]
  | .node m _ cs => (List.range m).flatMap fun i => (cs i).y1

/-- The language-2 sentence of the tree. -/
def y2 : Tree T → List T
  | .leaf _ b => [b]
  | .node _ π cs => π.flatMap fun i => (cs i).y2

/-- Well-formed: every node has at least one child and its `π` is a permutation. -/
def WF : Tree T → Prop
  | .leaf _ _ => True
  | .node m π cs => 0 < m ∧ π.Perm (List.range m) ∧ ∀ i, i < m → (cs i).WF

end Tree

/-! ## Equivalence points and realizations -/

/-- Definition 2: `j` is an equivalence point if the first `j` leaves of the two orders
are the same set. -/
def EqPt {α : Type} (l₁ l₂ : List α) (j : Nat) : Prop :=
  j ≤ l₁.length ∧ ∀ x, x ∈ l₁.take j ↔ x ∈ l₂.take j

/-- Realizations from cut `j` on: go to the *next* equivalence point `j'`, choose a
language, emit positions `j+1 … j'` of that language's order in that language. -/
inductive RealFrom {T : Type} (l₁ l₂ : List (Leaf T)) : Nat → List T → Prop
  | done {j : Nat} : j = l₁.length → RealFrom l₁ l₂ j []
  | seg1 {j j' : Nat} {z : List T} : j < j' → EqPt l₁ l₂ j' →
      (∀ k, j < k → k < j' → ¬ EqPt l₁ l₂ k) → RealFrom l₁ l₂ j' z →
      RealFrom l₁ l₂ j ((seg l₁ j j').map Leaf.w1 ++ z)
  | seg2 {j j' : Nat} {z : List T} : j < j' → EqPt l₁ l₂ j' →
      (∀ k, j < k → k < j' → ¬ EqPt l₁ l₂ k) → RealFrom l₁ l₂ j' z →
      RealFrom l₁ l₂ j ((seg l₂ j j').map Leaf.w2 ++ z)

/-- Definition 3, literally: one language per stretch between consecutive equivalence
points. -/
def RealEP {T : Type} (l₁ l₂ : List (Leaf T)) (z : List T) : Prop :=
  l₁.length = l₂.length ∧ RealFrom l₁ l₂ 0 z

/-- Remark 2 (chunk form): cut both orders into chunks that are rearrangements of each
other, and realize each chunk in one language.  Chunks need not be maximal. -/
inductive Real {T : Type} : List (Leaf T) → List (Leaf T) → List T → Prop
  | nil : Real [] [] []
  | chunk1 {x y l₁ l₂ : List (Leaf T)} {z : List T} : x.Perm y → Real l₁ l₂ z →
      Real (x ++ l₁) (y ++ l₂) (x.map Leaf.w1 ++ z)
  | chunk2 {x y l₁ l₂ : List (Leaf T)} {z : List T} : x.Perm y → Real l₁ l₂ z →
      Real (x ++ l₁) (y ++ l₂) (y.map Leaf.w2 ++ z)

namespace Real

variable {T : Type}

theorem perm {l₁ l₂ : List (Leaf T)} {z : List T} (h : Real l₁ l₂ z) : l₁.Perm l₂ := by
  induction h with
  | nil => exact .nil
  | chunk1 hxy _ ih => exact hxy.append ih
  | chunk2 hxy _ ih => exact hxy.append ih

theorem mono1 {x y : List (Leaf T)} (h : x.Perm y) : Real x y (x.map Leaf.w1) := by
  simpa using Real.chunk1 h Real.nil

theorem mono2 {x y : List (Leaf T)} (h : x.Perm y) : Real x y (y.map Leaf.w2) := by
  simpa using Real.chunk2 h Real.nil

theorem of_nil {l₁ l₂ : List (Leaf T)} {z : List T} (h : Real l₁ l₂ z) (h0 : l₁ = []) :
    z = [] := by
  induction h with
  | nil => rfl
  | chunk1 hxy _ ih =>
    obtain ⟨hx, hl⟩ := List.append_eq_nil_iff.mp h0
    subst hx
    simpa using ih hl
  | chunk2 hxy _ ih =>
    obtain ⟨hx, hl⟩ := List.append_eq_nil_iff.mp h0
    subst hx
    have hy := hxy.nil_eq
    subst hy
    simpa using ih hl

theorem append {a₁ a₂ b₁ b₂ : List (Leaf T)} {z₁ z₂ : List T} (h : Real a₁ a₂ z₁)
    (h' : Real b₁ b₂ z₂) : Real (a₁ ++ b₁) (a₂ ++ b₂) (z₁ ++ z₂) := by
  induction h with
  | nil => simpa using h'
  | chunk1 hxy _ ih =>
    simp only [List.append_assoc]
    exact Real.chunk1 hxy ih
  | chunk2 hxy _ ih =>
    simp only [List.append_assoc]
    exact Real.chunk2 hxy ih

/-- A realization can be split at any equivalence point. -/
theorem split {l₁ l₂ : List (Leaf T)} {z : List T} (h : Real l₁ l₂ z) :
    ∀ a₁ b₁ a₂ b₂, l₁ = a₁ ++ b₁ → l₂ = a₂ ++ b₂ → a₁.Perm a₂ →
      ∃ z₁ z₂, z = z₁ ++ z₂ ∧ Real a₁ a₂ z₁ ∧ Real b₁ b₂ z₂ := by
  induction h with
  | nil =>
    intro a₁ b₁ a₂ b₂ e₁ e₂ _
    obtain ⟨rfl, rfl⟩ := List.append_eq_nil_iff.mp e₁.symm
    obtain ⟨rfl, rfl⟩ := List.append_eq_nil_iff.mp e₂.symm
    exact ⟨[], [], rfl, .nil, .nil⟩
  | @chunk1 x y l₁ l₂ z hxy hr ih =>
    intro a₁ b₁ a₂ b₂ e₁ e₂ hp
    have hlen := hxy.length_eq
    have hlen' := hp.length_eq
    by_cases hc : x.length ≤ a₁.length
    · obtain ⟨r, rfl, rfl⟩ := append_split e₁ hc
      obtain ⟨r', rfl, rfl⟩ := append_split e₂ (by omega)
      obtain ⟨z₁, z₂, rfl, h₁, h₂⟩ := ih r b₁ r' b₂ rfl rfl (perm_cancel_left hxy hp)
      exact ⟨x.map Leaf.w1 ++ z₁, z₂, by simp, .chunk1 hxy h₁, h₂⟩
    · obtain ⟨r, rfl, rfl⟩ := append_split e₁.symm (by omega)
      obtain ⟨r', rfl, rfl⟩ := append_split e₂.symm (by omega)
      exact ⟨a₁.map Leaf.w1, r.map Leaf.w1 ++ z, by simp, mono1 hp,
        .chunk1 (perm_cancel_left hp hxy) hr⟩
  | @chunk2 x y l₁ l₂ z hxy hr ih =>
    intro a₁ b₁ a₂ b₂ e₁ e₂ hp
    have hlen := hxy.length_eq
    have hlen' := hp.length_eq
    by_cases hc : x.length ≤ a₁.length
    · obtain ⟨r, rfl, rfl⟩ := append_split e₁ hc
      obtain ⟨r', rfl, rfl⟩ := append_split e₂ (by omega)
      obtain ⟨z₁, z₂, rfl, h₁, h₂⟩ := ih r b₁ r' b₂ rfl rfl (perm_cancel_left hxy hp)
      exact ⟨y.map Leaf.w2 ++ z₁, z₂, by simp, .chunk2 hxy h₁, h₂⟩
    · obtain ⟨r, rfl, rfl⟩ := append_split e₁.symm (by omega)
      obtain ⟨r', rfl, rfl⟩ := append_split e₂.symm (by omega)
      exact ⟨a₂.map Leaf.w2, r'.map Leaf.w2 ++ z, by simp, mono2 hp,
        .chunk2 (perm_cancel_left hp hxy) hr⟩

/-- A realization is monolingual, or there is an equivalence point strictly inside. -/
theorem mono_or_cut {l₁ l₂ : List (Leaf T)} {z : List T} (h : Real l₁ l₂ z) :
    (z = l₁.map Leaf.w1 ∨ z = l₂.map Leaf.w2) ∨
      ∃ a₁ b₁ a₂ b₂, l₁ = a₁ ++ b₁ ∧ l₂ = a₂ ++ b₂ ∧ a₁.Perm a₂ ∧ a₁ ≠ [] ∧ b₁ ≠ [] := by
  induction h with
  | nil => exact .inl (.inl rfl)
  | @chunk1 x y l₁ l₂ z hxy hr ih =>
    by_cases hx : x = []
    · subst hx
      have hy := hxy.nil_eq
      subst hy
      simpa using ih
    · by_cases hl : l₁ = []
      · subst hl
        have hz := hr.of_nil rfl
        have hl2 := hr.perm.nil_eq
        subst hz; subst hl2
        exact .inl (.inl (by simp))
      · exact .inr ⟨x, l₁, y, l₂, rfl, rfl, hxy, hx, hl⟩
  | @chunk2 x y l₁ l₂ z hxy hr ih =>
    by_cases hx : x = []
    · subst hx
      have hy := hxy.nil_eq
      subst hy
      simpa using ih
    · by_cases hl : l₁ = []
      · subst hl
        have hz := hr.of_nil rfl
        have hl2 := hr.perm.nil_eq
        subst hz; subst hl2
        exact .inl (.inr (by simp))
      · exact .inr ⟨x, l₁, y, l₂, rfl, rfl, hxy, hx, hl⟩

end Real

/-! ## The two forms of realization agree -/

section RealEPReal

variable {T : Type}

theorem mem_seg {α : Type} {l : List α} (hn : l.Nodup) {j j' : Nat} (h : j ≤ j') (x : α) :
    x ∈ seg l j j' ↔ x ∈ l.take j' ∧ x ∉ l.take j := by
  have e := take_eq_take_append_seg l h
  have hn' : (l.take j ++ seg l j j').Nodup := e ▸ (List.take_sublist j' l).nodup hn
  have hd := (List.nodup_append.mp hn').2.2
  rw [e, List.mem_append]
  constructor
  · intro hx
    exact ⟨.inr hx, fun hx' => hd x hx' x hx rfl⟩
  · rintro ⟨hx | hx, hx'⟩
    · exact absurd hx hx'
    · exact hx

theorem seg_perm {α : Type} {l₁ l₂ : List α} (h₁ : l₁.Nodup) (h₂ : l₂.Nodup) {j j' : Nat}
    (h : j ≤ j') (e : EqPt l₁ l₂ j) (e' : EqPt l₁ l₂ j') : (seg l₁ j j').Perm (seg l₂ j j') := by
  have n₁ : (seg l₁ j j').Nodup :=
    ((List.take_sublist _ _).trans (List.drop_sublist _ _)).nodup h₁
  have n₂ : (seg l₂ j j').Nodup :=
    ((List.take_sublist _ _).trans (List.drop_sublist _ _)).nodup h₂
  refine (List.perm_ext_iff_of_nodup n₁ n₂).mpr (fun x => ?_)
  rw [mem_seg h₁ h, mem_seg h₂ h, e.2 x, e'.2 x]

theorem real_of_realFrom {l₁ l₂ : List (Leaf T)} (h₁ : l₁.Nodup) (h₂ : l₂.Nodup)
    (hlen : l₁.length = l₂.length) {j : Nat} {z : List T} (h : RealFrom l₁ l₂ j z) :
    EqPt l₁ l₂ j → Real (l₁.drop j) (l₂.drop j) z := by
  induction h with
  | done hj =>
    intro _
    subst hj
    have : l₂.drop l₁.length = [] := by rw [hlen]; simp
    simpa [this] using (Real.nil : Real (T := T) [] [] [])
  | @seg1 j j' z hjj' he' _ _ ih =>
    intro he
    rw [drop_eq_seg_append l₁ (Nat.le_of_lt hjj'), drop_eq_seg_append l₂ (Nat.le_of_lt hjj')]
    exact .chunk1 (seg_perm h₁ h₂ (Nat.le_of_lt hjj') he he') (ih he')
  | @seg2 j j' z hjj' he' _ _ ih =>
    intro he
    rw [drop_eq_seg_append l₁ (Nat.le_of_lt hjj'), drop_eq_seg_append l₂ (Nat.le_of_lt hjj')]
    exact .chunk2 (seg_perm h₁ h₂ (Nat.le_of_lt hjj') he he') (ih he')

theorem realFrom_of_real {l₁ l₂ : List (Leaf T)} (h₁ : l₁.Nodup) (h₂ : l₂.Nodup)
    (hp : l₁.Perm l₂) :
    ∀ (n j : Nat) (z : List T), l₁.length - j = n → EqPt l₁ l₂ j →
      Real (l₁.drop j) (l₂.drop j) z → RealFrom l₁ l₂ j z := by
  have hlen := hp.length_eq
  intro n
  induction n using Nat.strongRecOn with
  | _ n ih =>
    intro j z hn he hr
    by_cases hj : j = l₁.length
    · have : l₁.drop j = [] := by rw [hj]; simp
      rw [hr.of_nil this]
      exact .done hj
    · have hjlt : j < l₁.length := Nat.lt_of_le_of_ne he.1 hj
      -- the next equivalence point after `j`
      have hend : j < l₁.length ∧ EqPt l₁ l₂ l₁.length := by
        refine ⟨hjlt, Nat.le_refl _, fun x => ?_⟩
        rw [List.take_length, hlen, List.take_length]
        exact hp.mem_iff
      obtain ⟨j', ⟨hjj', he'⟩, hmin⟩ :=
        exists_least (fun k => j < k ∧ EqPt l₁ l₂ k) l₁.length hend
      have hle := Nat.le_of_lt hjj'
      have hsp := seg_perm h₁ h₂ hle he he'
      obtain ⟨z₁, z₂, rfl, hr₁, hr₂⟩ := hr.split _ _ _ _
        (drop_eq_seg_append l₁ hle) (drop_eq_seg_append l₂ hle) hsp
      have hrest := ih (l₁.length - j') (by omega) j' z₂ rfl he' hr₂
      have hno : ∀ k, j < k → k < j' → ¬ EqPt l₁ l₂ k :=
        fun k hk hk' hek => hmin k hk' ⟨hk, hek⟩
      rcases hr₁.mono_or_cut with (rfl | rfl) | ⟨a₁, b₁, a₂, b₂, e₁, e₂, hpa, ha, hb⟩
      · exact .seg1 hjj' he' hno hrest
      · exact .seg2 hjj' he' hno hrest
      · exfalso
        have hj' := he'.1
        have hsl := seg_length l₁ hle hj'
        have hla : 0 < a₁.length := List.length_pos_iff.mpr ha
        have hlb : 0 < b₁.length := List.length_pos_iff.mpr hb
        have hsum : a₁.length + b₁.length = j' - j := by
          rw [← hsl, e₁, List.length_append]
        have d₁ : l₁.drop j = a₁ ++ (b₁ ++ l₁.drop j') := by
          rw [drop_eq_seg_append l₁ hle, e₁, List.append_assoc]
        have d₂ : l₂.drop j = a₂ ++ (b₂ ++ l₂.drop j') := by
          rw [drop_eq_seg_append l₂ hle, e₂, List.append_assoc]
        refine hno (j + a₁.length) (by omega) (by omega) ⟨by omega, fun x => ?_⟩
        rw [take_seg d₁, hpa.length_eq, take_seg d₂, List.mem_append, List.mem_append,
          he.2 x, hpa.mem_iff]

/-- The literal definition and the chunk form define the same realizations. -/
theorem realEP_iff_real {l₁ l₂ : List (Leaf T)} (h₁ : l₁.Nodup) (hp : l₁.Perm l₂)
    (z : List T) : RealEP l₁ l₂ z ↔ Real l₁ l₂ z := by
  have h₂ := hp.nodup_iff.mp h₁
  have e0 : EqPt l₁ l₂ 0 := ⟨Nat.zero_le _, fun x => by simp⟩
  constructor
  · rintro ⟨hlen, h⟩
    simpa using real_of_realFrom h₁ h₂ hlen h e0
  · intro h
    exact ⟨hp.length_eq, realFrom_of_real h₁ h₂ hp _ 0 z rfl e0 (by simpa using h)⟩

end RealEPReal

/-! ## Blocks of a permutation -/

/-- A block of a permutation, given by the two orders of its children: `J` rearranges
`I`, and no proper non-empty prefix of `I` is rearranged by the prefix of `J` of the
same length (there is no boundary strictly inside). -/
def Irr (I J : List Nat) : Prop :=
  I ≠ [] ∧ I.Perm J ∧
    ∀ Ia Ib Ja Jb, I = Ia ++ Ib → J = Ja ++ Jb → Ia.Perm Ja → Ia = [] ∨ Ib = []

/-- `bs` is the block decomposition of the pair of orders `I`, `J`. -/
def Blocks (I J : List Nat) (bs : List (List Nat × List Nat)) : Prop :=
  I = (bs.map Prod.fst).flatten ∧ J = (bs.map Prod.snd).flatten ∧
    ∀ b, b ∈ bs → Irr b.1 b.2

theorem Blocks.mem_left {I J : List Nat} {bs : List (List Nat × List Nat)}
    (h : Blocks I J bs) {b : List Nat × List Nat} (hb : b ∈ bs) {i : Nat} (hi : i ∈ b.1) :
    i ∈ I := by
  rw [h.1]
  exact List.mem_flatten.mpr ⟨b.1, List.mem_map.mpr ⟨b, hb, rfl⟩, hi⟩

/-- Every pair of orders has a block decomposition (cut at the first boundary, repeat). -/
theorem exists_blocks :
    ∀ (n : Nat) (I J : List Nat), I.length = n → I.Perm J → ∃ bs, Blocks I J bs := by
  intro n
  induction n using Nat.strongRecOn with
  | _ n ih =>
    intro I J hn hp
    by_cases hI : I = []
    · subst hI
      have := hp.nil_eq
      subst this
      exact ⟨[], rfl, rfl, fun b hb => by cases hb⟩
    · have hlen := hp.length_eq
      have hpos : 0 < I.length := List.length_pos_iff.mpr hI
      have hfull : 0 < I.length ∧ (I.take I.length).Perm (J.take I.length) := by
        refine ⟨hpos, ?_⟩
        rw [List.take_length, hlen, List.take_length]
        exact hp
      obtain ⟨k, ⟨hk, hkp⟩, hmin⟩ :=
        exists_least (fun k => 0 < k ∧ (I.take k).Perm (J.take k)) I.length hfull
      have hkle : k ≤ I.length := Nat.le_of_not_lt (fun h => hmin _ h hfull)
      have hrest : (I.drop k).Perm (J.drop k) :=
        perm_cancel_left hkp (by rw [List.take_append_drop, List.take_append_drop]; exact hp)
      obtain ⟨bs, hb1, hb2, hb3⟩ :=
        ih (I.drop k).length (by rw [List.length_drop]; omega) _ _ rfl hrest
      refine ⟨(I.take k, J.take k) :: bs, ?_, ?_, ?_⟩
      · simp only [List.map_cons, List.flatten_cons]
        rw [← hb1, List.take_append_drop]
      · simp only [List.map_cons, List.flatten_cons]
        rw [← hb2, List.take_append_drop]
      · intro b hb
        rcases List.mem_cons.mp hb with rfl | hb
        · refine ⟨?_, hkp, ?_⟩
          · intro h0
            have h0' : I.take k = [] := h0
            have := congrArg List.length h0'
            rw [List.length_take, List.length_nil] at this
            omega
          · intro Ia Ib Ja Jb e₁ e₂ hpa
            by_cases ha : Ia = []
            · exact .inl ha
            · by_cases hb' : Ib = []
              · exact .inr hb'
              · exfalso
                have la : 0 < Ia.length := List.length_pos_iff.mpr ha
                have lb : 0 < Ib.length := List.length_pos_iff.mpr hb'
                have ltk : (I.take k).length = k := by rw [List.length_take]; omega
                have hsum : Ia.length + Ib.length = k := by
                  rw [← ltk]; simp only at e₁; rw [e₁, List.length_append]
                refine hmin Ia.length (by omega) ⟨la, ?_⟩
                have t1 : I.take Ia.length = Ia := by
                  have h := congrArg (List.take Ia.length) e₁
                  simp only at h
                  rw [List.take_take, List.take_left' rfl, Nat.min_eq_left (by omega)] at h
                  exact h
                have t2 : J.take Ia.length = Ja := by
                  have h := congrArg (List.take Ia.length) e₂
                  simp only at h
                  rw [List.take_take, List.take_left' hpa.length_eq.symm,
                    Nat.min_eq_left (by omega)] at h
                  exact h
                rw [t1, t2]
                exact hpa
        · exact hb3 b hb

theorem exists_blocksOf (m : Nat) (π : List Nat) :
    ∃ bs, π.Perm (List.range m) → Blocks (List.range m) π bs := by
  by_cases h : π.Perm (List.range m)
  · obtain ⟨bs, hbs⟩ := exists_blocks _ (List.range m) π rfl h.symm
    exact ⟨bs, fun _ => hbs⟩
  · exact ⟨[], fun h' => absurd h' h⟩

/-- The block decomposition of `π` against `0, …, m-1`.  It is obtained from the
existence proof, not computed. -/
noncomputable def blocksOf (m : Nat) (π : List Nat) : List (List Nat × List Nat) :=
  Classical.choose (exists_blocksOf m π)

theorem blocksOf_spec {m : Nat} {π : List Nat} (h : π.Perm (List.range m)) :
    Blocks (List.range m) π (blocksOf m π) :=
  Classical.choose_spec (exists_blocksOf m π) h

/-- An irreducible pair is its own (only) block decomposition. -/
theorem blocks_of_irr {I J : List Nat} {bs : List (List Nat × List Nat)} (h : Irr I J)
    (hB : Blocks I J bs) : bs = [(I, J)] := by
  obtain ⟨hI, hJ, hirr⟩ := hB
  cases bs with
  | nil => exact absurd hI h.1
  | cons b bs =>
    simp only [List.map_cons, List.flatten_cons] at hI hJ
    have hb := hirr b List.mem_cons_self
    rcases h.2.2 _ _ _ _ hI hJ hb.2.1 with h0 | h0
    · exact absurd h0 hb.1
    · have hbs : bs = [] := by
        cases bs with
        | nil => rfl
        | cons c bs' =>
          exfalso
          have hc := hirr c (List.mem_cons_of_mem _ List.mem_cons_self)
          simp only [List.map_cons, List.flatten_cons] at h0
          exact hc.1 (List.append_eq_nil_iff.mp h0).1
      subst hbs
      simp only [List.map_nil, List.flatten_nil, List.append_nil] at hI hJ
      subst hI; subst hJ
      rfl

/-! ## No equivalence point inside a non-singleton block -/

/-- Where a cut of a concatenation of pieces falls: at a piece boundary, or strictly
inside one piece. -/
theorem flatMap_cut {α : Type} (w : Nat → List α) :
    ∀ (K : List Nat) (a b : List α), K.flatMap w = a ++ b →
      ∃ Ka Kb p, K = Ka ++ Kb ∧ a = Ka.flatMap w ++ p ∧
        ((p = [] ∧ b = Kb.flatMap w) ∨
          ∃ k r s, Kb = k :: r ∧ w k = p ++ s ∧ p ≠ [] ∧ s ≠ []) := by
  intro K
  induction K with
  | nil =>
    intro a b h
    have h' : a ++ b = [] := by simpa using h.symm
    obtain ⟨rfl, rfl⟩ := List.append_eq_nil_iff.mp h'
    exact ⟨[], [], [], rfl, rfl, .inl ⟨rfl, rfl⟩⟩
  | cons k K ih =>
    intro a b h
    rw [List.flatMap_cons] at h
    by_cases hc : (w k).length ≤ a.length
    · obtain ⟨a', rfl, h'⟩ := append_split h hc
      obtain ⟨Ka, Kb, p, rfl, rfl, hcase⟩ := ih a' b h'
      exact ⟨k :: Ka, Kb, p, rfl, by simp, hcase⟩
    · obtain ⟨s, hw, hb⟩ := append_split h.symm (by omega)
      by_cases ha : a = []
      · subst ha
        refine ⟨[], k :: K, [], rfl, rfl, .inl ⟨rfl, ?_⟩⟩
        rw [List.nil_append] at hw
        rw [hb, List.flatMap_cons, hw]
      · refine ⟨[], k :: K, a, rfl, by simp, .inr ⟨k, K, s, rfl, hw, ha, ?_⟩⟩
        intro hs
        subst hs
        rw [List.append_nil] at hw
        rw [hw] at hc
        exact hc (Nat.le_refl _)

/-- The children that lie wholly before the cut in one order lie wholly before it in
the other. -/
theorem cut_sub {α : Type} {u v : Nat → List α} {tag : α → Nat}
    {I J Ia Ib Ja Jb : List Nat} {p₁ p₂ a₁ a₂ : List α}
    (hu : ∀ i, i ∈ I → u i ≠ [] ∧ ∀ x, x ∈ u i → tag x = i)
    (hv : ∀ j, j ∈ J → (v j).Nodup ∧ ∀ x, x ∈ v j → tag x = j)
    (huv : ∀ i, i ∈ I → ∀ x, x ∈ u i ↔ x ∈ v i)
    (hJn : J.Nodup) (hI : I = Ia ++ Ib) (hJ : J = Ja ++ Jb)
    (h₁ : a₁ = Ia.flatMap u ++ p₁) (h₂ : a₂ = Ja.flatMap v ++ p₂)
    (hp₂ : p₂ = [] ∨ ∃ k r s, Jb = k :: r ∧ v k = p₂ ++ s ∧ p₂ ≠ [] ∧ s ≠ [])
    (ha : ∀ x, x ∈ a₁ ↔ x ∈ a₂) : ∀ k, k ∈ Ia → k ∈ Ja := by
  intro k hk
  have hkI : k ∈ I := by rw [hI]; exact List.mem_append_left _ hk
  obtain ⟨hne, htag⟩ := hu k hkI
  obtain ⟨x, hx⟩ := List.exists_mem_of_ne_nil _ hne
  have hin : ∀ y, y ∈ u k → y ∈ Ja.flatMap v ++ p₂ := fun y hy => by
    rw [← h₂]
    exact (ha y).mp (by rw [h₁]; exact List.mem_append_left _ (List.mem_flatMap.mpr ⟨k, hk, hy⟩))
  have key : ∀ y, y ∈ u k → y ∈ Ja.flatMap v → k ∈ Ja := by
    intro y hy hy'
    obtain ⟨k', hk', hyk'⟩ := List.mem_flatMap.mp hy'
    have e1 : tag y = k' := (hv k' (by rw [hJ]; exact List.mem_append_left _ hk')).2 y hyk'
    have e2 : k' = k := by rw [← e1, htag y hy]
    rw [← e2]
    exact hk'
  rcases List.mem_append.mp (hin x hx) with hx2 | hx2
  · exact key x hx hx2
  · rcases hp₂ with hnil | ⟨j, r, s, hJb, hvj, _, hs⟩
    · rw [hnil] at hx2
      cases hx2
    · exfalso
      have hjJ : j ∈ J := by rw [hJ, hJb]; simp
      have hxj : x ∈ v j := by rw [hvj]; exact List.mem_append_left _ hx2
      have hjk : j = k := by rw [← (hv j hjJ).2 x hxj, htag x hx]
      rw [hjk] at hvj hJb
      have hnd := (hv k (hjk ▸ hjJ)).1
      obtain ⟨y, hy⟩ := List.exists_mem_of_ne_nil _ hs
      have hyv : y ∈ v k := by rw [hvj]; exact List.mem_append_right _ hy
      have hyu : y ∈ u k := (huv k hkI y).mpr hyv
      rcases List.mem_append.mp (hin y hyu) with hy2 | hy2
      · have hkJa := key y hyu hy2
        rw [hJ, hJb] at hJn
        exact (List.nodup_append.mp hJn).2.2 k hkJa k List.mem_cons_self rfl
      · rw [hvj] at hnd
        exact (List.nodup_append.mp hnd).2.2 y hy2 y hy rfl

/-- What is assumed of the children of one node: the two yields of a child are
rearrangements of each other, non-empty, without repetition, and every leaf knows which
child it belongs to. -/
def Fam {α : Type} (u v : Nat → List α) (tag : α → Nat) (I : List Nat) : Prop :=
  ∀ i, i ∈ I → (u i).Perm (v i) ∧ u i ≠ [] ∧ (u i).Nodup ∧ ∀ x, x ∈ u i → tag x = i

/-- There is no equivalence point strictly inside a non-singleton block. -/
theorem no_cut_inside {α : Type} {u v : Nat → List α} {tag : α → Nat} {I J : List Nat}
    (hirr : Irr I J) (h2 : 2 ≤ I.length) (hIn : I.Nodup) (hF : Fam u v tag I)
    {a₁ b₁ a₂ b₂ : List α} (e₁ : I.flatMap u = a₁ ++ b₁) (e₂ : J.flatMap v = a₂ ++ b₂)
    (hp : a₁.Perm a₂) : a₁ = [] ∨ b₁ = [] := by
  obtain ⟨_, hIJ, hcut⟩ := hirr
  have hJn : J.Nodup := hIJ.nodup_iff.mp hIn
  have hJI : ∀ j, j ∈ J → j ∈ I := fun j hj => hIJ.mem_iff.mpr hj
  obtain ⟨Ia, Ib, p₁, hI, ha₁, hc₁⟩ := flatMap_cut u I a₁ b₁ e₁
  obtain ⟨Ja, Jb, p₂, hJ, ha₂, hc₂⟩ := flatMap_cut v J a₂ b₂ e₂
  have hu : ∀ i, i ∈ I → u i ≠ [] ∧ ∀ x, x ∈ u i → tag x = i :=
    fun i hi => ⟨(hF i hi).2.1, (hF i hi).2.2.2⟩
  have hv : ∀ j, j ∈ J → v j ≠ [] ∧ ∀ x, x ∈ v j → tag x = j := fun j hj => by
    obtain ⟨hpj, hne, _, ht⟩ := hF j (hJI j hj)
    refine ⟨fun h0 => hne ?_, fun x hx => ht x (hpj.mem_iff.mpr hx)⟩
    rw [h0] at hpj
    exact hpj.eq_nil
  have hun : ∀ i, i ∈ I → (u i).Nodup ∧ ∀ x, x ∈ u i → tag x = i :=
    fun i hi => ⟨(hF i hi).2.2.1, (hF i hi).2.2.2⟩
  have hvn : ∀ j, j ∈ J → (v j).Nodup ∧ ∀ x, x ∈ v j → tag x = j :=
    fun j hj => ⟨(hF j (hJI j hj)).1.nodup_iff.mp (hF j (hJI j hj)).2.2.1, (hv j hj).2⟩
  have huv : ∀ i, i ∈ I → ∀ x, x ∈ u i ↔ x ∈ v i := fun i hi x => (hF i hi).1.mem_iff
  have hvu : ∀ j, j ∈ J → ∀ x, x ∈ v j ↔ x ∈ u j :=
    fun j hj x => ((hF j (hJI j hj)).1.mem_iff).symm
  have sub1 : ∀ k, k ∈ Ia → k ∈ Ja :=
    cut_sub hu hvn huv hJn hI hJ ha₁ ha₂ (hc₂.imp (fun h => h.1) id) (fun _ => hp.mem_iff)
  have sub2 : ∀ k, k ∈ Ja → k ∈ Ia :=
    cut_sub hv hun hvu hIn hJ hI ha₂ ha₁ (hc₁.imp (fun h => h.1) id)
      (fun _ => hp.mem_iff.symm)
  have hIan : Ia.Nodup := by rw [hI] at hIn; exact (List.nodup_append.mp hIn).1
  have hJan : Ja.Nodup := by rw [hJ] at hJn; exact (List.nodup_append.mp hJn).1
  have hpa : Ia.Perm Ja :=
    (List.perm_ext_iff_of_nodup hIan hJan).mpr (fun k => ⟨sub1 k, sub2 k⟩)
  rcases hcut Ia Ib Ja Jb hI hJ hpa with hIa | hIb
  · subst hIa
    have hJa := hpa.nil_eq
    subst hJa
    simp only [List.flatMap_nil, List.nil_append] at ha₁ ha₂ hI hJ
    rcases hc₁ with ⟨hp1, _⟩ | ⟨i, r, s₁, hIb, hui, hp1, _⟩
    · left; rw [ha₁, hp1]
    · rcases hc₂ with ⟨hp2, _⟩ | ⟨j, r', s₂, hJb, hvj, _, _⟩
      · exfalso
        rw [ha₁, ha₂, hp2] at hp
        exact hp1 hp.eq_nil
      · exfalso
        obtain ⟨x, hx⟩ := List.exists_mem_of_ne_nil _ hp1
        have hiI : i ∈ I := by rw [hI, hIb]; exact List.mem_cons_self
        have hjJ : j ∈ J := by rw [hJ, hJb]; exact List.mem_cons_self
        have t1 : tag x = i := (hu i hiI).2 x (by rw [hui]; exact List.mem_append_left _ hx)
        have hx2 : x ∈ p₂ := by rw [← ha₂]; exact hp.mem_iff.mp (by rw [ha₁]; exact hx)
        have t2 : tag x = j := (hv j hjJ).2 x (by rw [hvj]; exact List.mem_append_left _ hx2)
        have hij : j = i := t2.symm.trans t1
        rw [hIb] at hI
        rw [hJb, hij] at hJ
        rcases hcut [i] r [i] r' hI hJ (List.Perm.refl _) with h | h
        · cases h
        · rw [hI, h] at h2
          simp at h2
  · subst hIb
    rcases hc₁ with ⟨_, hb⟩ | ⟨i, r, s, hIb, _⟩
    · right; simpa using hb
    · cases hIb

/-- On a non-singleton block every realization is monolingual. -/
theorem irr_flat {T : Type} {u v : Nat → List (Leaf T)} {tag : Leaf T → Nat} {I J : List Nat}
    (hirr : Irr I J) (h2 : 2 ≤ I.length) (hIn : I.Nodup) (hF : Fam u v tag I) {z : List T}
    (h : Real (I.flatMap u) (J.flatMap v) z) :
    z = (I.flatMap u).map Leaf.w1 ∨ z = (J.flatMap v).map Leaf.w2 := by
  rcases h.mono_or_cut with h | ⟨a₁, b₁, a₂, b₂, e₁, e₂, hp, ha, hb⟩
  · exact h
  · rcases no_cut_inside hirr h2 hIn hF e₁ e₂ hp with h | h
    · exact absurd h ha
    · exact absurd h hb

/-! ## One node -/

/-- What one block contributes: a singleton block `{i}` contributes whatever child `i`
does (`R i`); a larger block contributes its language-1 or its language-2 sentence. -/
def Piece {T : Type} (R : Nat → List T → Prop) (m₁ m₂ : List Nat → List T)
    (b : List Nat × List Nat) (zk : List T) : Prop :=
  (∃ i, b.1 = [i] ∧ R i zk) ∨ (2 ≤ b.1.length ∧ (zk = m₁ b.1 ∨ zk = m₂ b.2))

theorem Piece.imp {T : Type} {R R' : Nat → List T → Prop} {m₁ m₁' m₂ m₂' : List Nat → List T}
    {b : List Nat × List Nat} {zk : List T} (hR : ∀ i, i ∈ b.1 → R i zk → R' i zk)
    (h1 : m₁ b.1 = m₁' b.1) (h2 : m₂ b.2 = m₂' b.2) :
    Piece R m₁ m₂ b zk → Piece R' m₁' m₂' b zk := by
  rintro (⟨i, hi, hr⟩ | ⟨h, hz⟩)
  · exact .inl ⟨i, hi, hR i (by rw [hi]; exact List.mem_cons_self) hr⟩
  · exact .inr ⟨h, by rw [← h1, ← h2]; exact hz⟩

/-- Lemma 1 and Corollary 1 at one node: the realizations of a node are exactly the
concatenations, block by block, of a realization of the child (singleton block) or a
monolingual sentence (non-singleton block). -/
theorem node_theorem {T : Type} {u v : Nat → List (Leaf T)} {tag : Leaf T → Nat} :
    ∀ (bs : List (List Nat × List Nat)) (I J : List Nat), Blocks I J bs → I.Nodup →
      Fam u v tag I → ∀ z,
      (Real (I.flatMap u) (J.flatMap v) z ↔
        ∃ zs : List (List T), z = zs.flatten ∧
          All2 (Piece (fun i zk => Real (u i) (v i) zk)
            (fun K => (K.flatMap u).map Leaf.w1) (fun K => (K.flatMap v).map Leaf.w2)) bs zs) := by
  intro bs
  induction bs with
  | nil =>
    intro I J hB _ _ z
    obtain ⟨rfl, rfl, _⟩ := hB
    constructor
    · intro h
      exact ⟨[], h.of_nil rfl, .nil⟩
    · rintro ⟨zs, rfl, h⟩
      cases h
      exact .nil
  | cons b bs ih =>
    intro I J hB hIn hF z
    obtain ⟨hI, hJ, hirr⟩ := hB
    simp only [List.map_cons, List.flatten_cons] at hI hJ
    have hB' : Blocks (bs.map Prod.fst).flatten (bs.map Prod.snd).flatten bs :=
      ⟨rfl, rfl, fun c hc => hirr c (List.mem_cons_of_mem _ hc)⟩
    have hb := hirr b List.mem_cons_self
    subst hI; subst hJ
    have hIn1 := (List.nodup_append.mp hIn).1
    have hIn2 := (List.nodup_append.mp hIn).2.1
    have hF1 : Fam u v tag b.1 := fun i hi => hF i (List.mem_append_left _ hi)
    have hF2 : Fam u v tag (bs.map Prod.fst).flatten :=
      fun i hi => hF i (List.mem_append_right _ hi)
    have hpb : (b.1.flatMap u).Perm (b.2.flatMap v) :=
      perm_flatMap hb.2.1 (fun i hi => (hF1 i hi).1)
    rw [List.flatMap_append, List.flatMap_append]
    constructor
    · intro h
      obtain ⟨z₁, z₂, rfl, h₁, h₂⟩ := h.split _ _ _ _ rfl rfl hpb
      obtain ⟨zs, rfl, hzs⟩ := (ih _ _ hB' hIn2 hF2 z₂).mp h₂
      refine ⟨z₁ :: zs, by simp, .cons ?_ hzs⟩
      by_cases h1 : b.1.length = 1
      · obtain ⟨i, hi⟩ := List.length_eq_one_iff.mp h1
        have hi2 : b.2 = [i] := by
          have := hb.2.1
          rw [hi] at this
          exact (List.singleton_perm.mp this).symm
        refine .inl ⟨i, hi, ?_⟩
        rw [hi, hi2] at h₁
        simpa using h₁
      · have h2 : 2 ≤ b.1.length := by
          have := List.length_pos_iff.mpr hb.1
          omega
        exact .inr ⟨h2, irr_flat ⟨hb.1, hb.2.1, hb.2.2⟩ h2 hIn1 hF1 h₁⟩
    · rintro ⟨zs, rfl, hzs⟩
      cases hzs with
      | @cons _ z₁ _ zs' hp hrest =>
        have h₂ := (ih _ _ hB' hIn2 hF2 _).mpr ⟨zs', rfl, hrest⟩
        rw [List.flatten_cons]
        refine Real.append ?_ h₂
        rcases hp with ⟨i, hi, hr⟩ | ⟨_, rfl | rfl⟩
        · have hi2 : b.2 = [i] := by
            have := hb.2.1
            rw [hi] at this
            exact (List.singleton_perm.mp this).symm
          rw [hi, hi2]
          simpa using hr
        · exact Real.mono1 hpb
        · exact Real.mono2 hpb

/-! ## Trees -/

namespace Tree

variable {T : Type}

theorem lin1_addr (t : Tree T) :
    ∀ (p : List Nat) (x : Leaf T), x ∈ t.lin1 p → ∃ r, x.addr = p ++ r := by
  induction t with
  | leaf a b =>
    intro p x hx
    simp only [lin1, List.mem_singleton] at hx
    exact ⟨[], by rw [hx]; simp⟩
  | node m π cs ih =>
    intro p x hx
    simp only [lin1, List.mem_flatMap] at hx
    obtain ⟨i, _, hx⟩ := hx
    obtain ⟨r, hr⟩ := ih i _ x hx
    exact ⟨i :: r, by rw [hr]; simp⟩

/-- Which child of the node at address `p` a leaf lies under. -/
def childTag (p : List Nat) (x : Leaf T) : Nat := x.addr.getD p.length 0

theorem childTag_lin1 (t : Tree T) (p : List Nat) (i : Nat) (x : Leaf T)
    (hx : x ∈ t.lin1 (p ++ [i])) : childTag p x = i := by
  obtain ⟨r, hr⟩ := lin1_addr t _ x hx
  simp [childTag, hr]

theorem lin_perm (t : Tree T) : t.WF → ∀ p, (t.lin1 p).Perm (t.lin2 p) := by
  induction t with
  | leaf a b => intro _ p; exact List.Perm.refl _
  | node m π cs ih =>
    intro h p
    simp only [lin1, lin2]
    exact perm_flatMap h.2.1.symm (fun i hi => ih i (h.2.2 i (List.mem_range.mp hi)) _)

theorem lin1_ne_nil (t : Tree T) : t.WF → ∀ p, t.lin1 p ≠ [] := by
  induction t with
  | leaf a b => intro _ p; simp [lin1]
  | node m π cs ih =>
    intro h p h0
    simp only [lin1] at h0
    obtain ⟨x, hx⟩ := List.exists_mem_of_ne_nil _ (ih 0 (h.2.2 0 h.1) (p ++ [0]))
    exact List.eq_nil_iff_forall_not_mem.mp h0 x
      (List.mem_flatMap.mpr ⟨0, List.mem_range.mpr h.1, hx⟩)

theorem nodup_flatMap_of_tag {α : Type} {u : Nat → List α} {tag : α → Nat} :
    ∀ (I : List Nat), I.Nodup → (∀ i, i ∈ I → (u i).Nodup ∧ ∀ x, x ∈ u i → tag x = i) →
      (I.flatMap u).Nodup := by
  intro I
  induction I with
  | nil => intro _ _; simp
  | cons i I ih =>
    intro hn h
    obtain ⟨hi, hn'⟩ := List.nodup_cons.mp hn
    rw [List.flatMap_cons]
    refine List.nodup_append.mpr ⟨(h i List.mem_cons_self).1,
      ih hn' (fun j hj => h j (List.mem_cons_of_mem _ hj)), ?_⟩
    intro a ha b hb hab
    obtain ⟨j, hj, hbj⟩ := List.mem_flatMap.mp hb
    have e1 := (h i List.mem_cons_self).2 a ha
    have e2 := (h j (List.mem_cons_of_mem _ hj)).2 b hbj
    rw [hab, e2] at e1
    exact hi (e1 ▸ hj)

theorem lin1_nodup (t : Tree T) : t.WF → ∀ p, (t.lin1 p).Nodup := by
  induction t with
  | leaf a b => intro _ p; simp [lin1]
  | node m π cs ih =>
    intro h p
    simp only [lin1]
    exact nodup_flatMap_of_tag (tag := childTag p) _ List.nodup_range
      (fun i hi => ⟨ih i (h.2.2 i (List.mem_range.mp hi)) _,
        fun x hx => childTag_lin1 _ _ _ _ hx⟩)

theorem lin1_map (t : Tree T) : ∀ p, (t.lin1 p).map Leaf.w1 = t.y1 := by
  induction t with
  | leaf a b => intro p; rfl
  | node m π cs ih => intro p; simp [lin1, y1, List.map_flatMap, ih]

theorem lin2_map (t : Tree T) : ∀ p, (t.lin2 p).map Leaf.w2 = t.y2 := by
  induction t with
  | leaf a b => intro p; rfl
  | node m π cs ih => intro p; simp [lin2, y2, List.map_flatMap, ih]

/-- The sentences the grammar `G_EC` assigns to a tree, read off the tree: at a leaf,
either word; at a node, block by block, the child's sentences (singleton block) or the
block's language-1 or language-2 sentence (non-singleton block). -/
def Gram : Tree T → List T → Prop
  | .leaf a b, z => z = [a] ∨ z = [b]
  | .node m π cs, z =>
    ∃ zs : List (List T), z = zs.flatten ∧
      All2 (Piece (fun i zk => (cs i).Gram zk)
        (fun K => K.flatMap fun i => (cs i).y1) (fun K => K.flatMap fun i => (cs i).y2))
        (blocksOf m π) zs

end Tree

open Tree in
/-- Tree-level theorem, chunk form. -/
theorem main_theorem {T : Type} (t : Tree T) :
    t.WF → ∀ (p : List Nat) (z : List T), Real (t.lin1 p) (t.lin2 p) z ↔ t.Gram z := by
  induction t with
  | leaf a b =>
    intro _ p z
    simp only [lin1, lin2, Gram]
    constructor
    · intro h
      rcases h.mono_or_cut with h | ⟨a₁, b₁, a₂, b₂, e₁, _, _, ha, hb⟩
      · simpa using h
      · exfalso
        have h1 := congrArg List.length e₁
        simp at h1
        have := List.length_pos_iff.mpr ha
        have := List.length_pos_iff.mpr hb
        omega
    · rintro (rfl | rfl)
      · exact Real.mono1 (List.Perm.refl _)
      · exact Real.mono2 (List.Perm.refl _)
  | node m π cs ih =>
    intro hwf p z
    obtain ⟨hm, hπ, hcs⟩ := hwf
    have hB := blocksOf_spec hπ
    have hF : Fam (fun i => (cs i).lin1 (p ++ [i])) (fun i => (cs i).lin2 (p ++ [i]))
        (childTag p) (List.range m) := fun i hi => by
      have hi' := List.mem_range.mp hi
      exact ⟨lin_perm _ (hcs i hi') _, lin1_ne_nil _ (hcs i hi') _, lin1_nodup _ (hcs i hi') _,
        fun x hx => childTag_lin1 _ _ _ _ hx⟩
    simp only [lin1, lin2, Gram]
    rw [node_theorem _ _ _ hB List.nodup_range hF z]
    constructor
    · rintro ⟨zs, hz, h⟩
      refine ⟨zs, hz, h.imp_mem (fun b zk hb => Piece.imp (fun i hi => ?_) ?_ ?_)⟩
      · exact (ih i (hcs i (List.mem_range.mp (hB.mem_left hb hi))) _ zk).mp
      · simp [List.map_flatMap, lin1_map]
      · simp [List.map_flatMap, lin2_map]
    · rintro ⟨zs, hz, h⟩
      refine ⟨zs, hz, h.imp_mem (fun b zk hb => Piece.imp (fun i hi => ?_) ?_ ?_)⟩
      · exact (ih i (hcs i (List.mem_range.mp (hB.mem_left hb hi))) _ zk).mpr
      · simp [List.map_flatMap, lin1_map]
      · simp [List.map_flatMap, lin2_map]

/-- Tree-level theorem, for the literal equivalence-point definition. -/
theorem main_theorem_EP {T : Type} (t : Tree T) (h : t.WF) (p : List Nat) (z : List T) :
    RealEP (t.lin1 p) (t.lin2 p) z ↔ t.Gram z := by
  rw [realEP_iff_real (Tree.lin1_nodup t h p) (Tree.lin_perm t h p)]
  exact main_theorem t h p z

/-! ## Example 1: opposite orders admit no switch -/

theorem irr_swap : Irr [0, 1] [1, 0] := by
  refine ⟨by simp, List.Perm.swap 1 0 [], ?_⟩
  intro Ia Ib Ja Jb e₁ e₂ hp
  have l1 := congrArg List.length e₁
  have l3 := hp.length_eq
  simp only [List.length_append, List.length_cons, List.length_nil] at l1
  by_cases h0 : Ia.length = 0
  · exact .inl (List.eq_nil_of_length_eq_zero h0)
  · by_cases h1 : Ia.length = 1
    · exfalso
      obtain ⟨a, rfl⟩ := List.length_eq_one_iff.mp h1
      obtain ⟨c, rfl⟩ := List.length_eq_one_iff.mp (l3 ▸ h1)
      simp only [List.cons_append, List.nil_append] at e₁ e₂
      injection e₁ with ha _
      injection e₂ with hc _
      have hac : a = c := by
        have := List.singleton_perm.mp hp
        injection this
      omega
    · exact .inr (List.eq_nil_of_length_eq_zero (by omega))

/-- Example 1: a clause whose two children come in opposite orders has only its two
monolingual sentences, whatever lies below. -/
theorem swapClause_gram {T : Type} (cs : Nat → Tree T) (z : List T) :
    (Tree.node 2 [1, 0] cs).Gram z ↔
      z = (Tree.node 2 [1, 0] cs).y1 ∨ z = (Tree.node 2 [1, 0] cs).y2 := by
  have hr : List.range 2 = [0, 1] := rfl
  have hπ : [1, 0].Perm (List.range 2) := by rw [hr]; exact List.Perm.swap 0 1 []
  have hbs : blocksOf 2 [1, 0] = [([0, 1], [1, 0])] :=
    blocks_of_irr irr_swap (hr ▸ blocksOf_spec hπ)
  simp only [Tree.Gram, Tree.y1, Tree.y2, hbs, hr]
  constructor
  · rintro ⟨zs, rfl, h⟩
    cases h with
    | cons hp ht =>
      cases ht
      rcases hp with ⟨i, hi, _⟩ | ⟨_, h | h⟩
      · simp at hi
      · left; simpa using h
      · right; simpa using h
  · rintro (h | h)
    · exact ⟨[z], by simp, .cons (.inr ⟨by simp, .inl h⟩) .nil⟩
    · exact ⟨[z], by simp, .cons (.inr ⟨by simp, .inr h⟩) .nil⟩

/-! # Part II: grammars -/

/-- A context-free grammar: a start symbol and a finite list of rules. -/
structure CFG (N T : Type) where
  start : N
  rules : List (N × List (N ⊕ T))

namespace CFG

variable {N T : Type}

/-- `G.Gen α s`: the string of symbols `α` derives the terminal string `s`. -/
inductive Gen (G : CFG N T) : List (N ⊕ T) → List T → Prop
  | nil : Gen G [] []
  | term {a : T} {α : List (N ⊕ T)} {s : List T} :
      Gen G α s → Gen G (.inr a :: α) (a :: s)
  | rule {A : N} {β α : List (N ⊕ T)} {s₁ s₂ : List T} :
      (A, β) ∈ G.rules → Gen G β s₁ → Gen G α s₂ → Gen G (.inl A :: α) (s₁ ++ s₂)

/-- The language of a grammar. -/
def Language (G : CFG N T) (s : List T) : Prop := G.Gen [.inl G.start] s

variable {G : CFG N T}

theorem Gen.append {α β : List (N ⊕ T)} {s t : List T} (h : G.Gen α s) (h' : G.Gen β t) :
    G.Gen (α ++ β) (s ++ t) := by
  induction h with
  | nil => simpa using h'
  | term _ ih => exact .term ih
  | rule hm hβ _ _ ih =>
    rw [List.append_assoc]
    exact .rule hm hβ ih

theorem Gen.single {A : N} {β : List (N ⊕ T)} {s : List T} (hm : (A, β) ∈ G.rules)
    (h : G.Gen β s) : G.Gen [.inl A] s := by
  simpa using Gen.rule hm h Gen.nil

theorem Gen.of_all2 {γ : Type} {f : γ → N ⊕ T} {l : List γ} {ss : List (List T)}
    (h : All2 (fun c s => G.Gen [f c] s) l ss) : G.Gen (l.map f) ss.flatten := by
  induction h with
  | nil => exact .nil
  | cons hab _ ih => exact Gen.append hab ih

theorem Gen.map_flatMap {f : Nat → N ⊕ T} {g : Nat → List T} :
    ∀ (K : List Nat), (∀ i, i ∈ K → G.Gen [f i] (g i)) → G.Gen (K.map f) (K.flatMap g) := by
  intro K
  induction K with
  | nil => intro _; exact .nil
  | cons k K ih =>
    intro h
    rw [List.flatMap_cons]
    exact Gen.append (h k List.mem_cons_self) (ih (fun i hi => h i (List.mem_cons_of_mem _ hi)))

end CFG

/-- A rule of the congruent pair (Definition 1): a lexical pair `A → w₁ / A → w₂`, or a
structural rule `A → X₀ ⋯ X_{m-1}` in language 1 together with the order `π` of the same
children in language 2, `A → X_{π[0]} ⋯ X_{π[m-1]}`. -/
inductive PRule (N T : Type) where
  | lex (A : N) (w₁ w₂ : T) : PRule N T
  | struct (A : N) (rhs : List N) (π : List Nat) : PRule N T

def PRule.WF {N T : Type} : PRule N T → Prop
  | .lex _ _ _ => True
  | .struct _ rhs π => rhs ≠ [] ∧ π.Perm (List.range rhs.length)

/-- Well-formed pair: every structural rule has at least one child and its `π` is a
permutation.  Nothing else is assumed (the grammars may be ambiguous, right-hand sides
may repeat symbols, the two vocabularies need not be disjoint). -/
def WFG {N T : Type} (P : List (PRule N T)) : Prop := ∀ r, r ∈ P → r.WF

/-- The `i`-th right-hand-side symbol (`A` is an irrelevant default). -/
def sym {N : Type} (rhs : List N) (A : N) (i : Nat) : N := rhs[i]?.getD A

theorem sym_eq {N : Type} (rhs : List N) (A : N) {i : Nat} (h : i < rhs.length) :
    rhs[i]? = some (sym rhs A i) := by
  simp [sym, List.getElem?_eq_getElem h]

theorem map_sym {N γ : Type} (rhs : List N) (A : N) (f : N → γ) :
    (List.range rhs.length).map (fun i => f (sym rhs A i)) = rhs.map f := by
  apply List.ext_getElem
  · simp
  · intro i h1 h2
    have h : i < rhs.length := by simpa using h2
    simp [sym, List.getElem?_eq_getElem h]

/-- The two monolingual grammars. -/
def lang1 {N T : Type} (P : List (PRule N T)) (S : N) : CFG N T :=
  ⟨S, P.map fun r => match r with
    | .lex A a _ => (A, [.inr a])
    | .struct A rhs _ => (A, rhs.map .inl)⟩

def lang2 {N T : Type} (P : List (PRule N T)) (S : N) : CFG N T :=
  ⟨S, P.map fun r => match r with
    | .lex A _ b => (A, [.inr b])
    | .struct A rhs π => (A, π.map fun i => .inl (sym rhs A i))⟩

/-- A derivation tree of the pair. In `node A rhs π cs` the children are
`cs 0, …, cs (rhs.length - 1)` in language-1 order. -/
inductive DTree (N T : Type) where
  | leaf (A : N) (w₁ w₂ : T) : DTree N T
  | node (A : N) (rhs : List N) (π : List Nat) (cs : Nat → DTree N T) : DTree N T

namespace DTree

variable {N T : Type}

def root : DTree N T → N
  | .leaf A _ _ => A
  | .node A _ _ _ => A

/-- Forget the labels. -/
def skel : DTree N T → Tree T
  | .leaf _ a b => .leaf a b
  | .node _ rhs π cs => .node rhs.length π (fun i => (cs i).skel)

/-- The tree uses rules of `P`, and the children carry the right-hand-side symbols. -/
def Valid (P : List (PRule N T)) : DTree N T → Prop
  | .leaf A a b => PRule.lex A a b ∈ P
  | .node A rhs π cs => PRule.struct A rhs π ∈ P ∧
      ∀ i, i < rhs.length → rhs[i]? = some (cs i).root ∧ (cs i).Valid P

/-- Leaves in language-1 order, identified by their address in the tree. -/
def lin1 (t : DTree N T) : List (Leaf T) := t.skel.lin1 []

/-- Leaves in language-2 order. -/
def lin2 (t : DTree N T) : List (Leaf T) := t.skel.lin2 []

theorem skel_wf {P : List (PRule N T)} (hW : WFG P) (t : DTree N T) :
    t.Valid P → t.skel.WF := by
  induction t with
  | leaf A a b => intro _; trivial
  | node A rhs π cs ih =>
    intro h
    have hw := hW _ h.1
    exact ⟨List.length_pos_iff.mpr hw.1, hw.2, fun i hi => ih i (h.2 i hi).2⟩

end DTree

/-- The language `L_EC`: all realizations (literal equivalence-point definition) of all
derivation trees rooted in `S`. -/
def LEC {N T : Type} (P : List (PRule N T)) (S : N) (s : List T) : Prop :=
  ∃ t : DTree N T, t.Valid P ∧ t.root = S ∧ RealEP t.lin1 t.lin2 s

/-! ## The grammar `G_EC` -/

/-- Nonterminals of `G_EC`: `A¹`, `A²`, `Aᴱ`, and one nonterminal per non-singleton
block, named by its two right-hand sides. -/
inductive NT (N : Type) where
  | l1 (A : N) : NT N
  | l2 (A : N) : NT N
  | e (A : N) : NT N
  | blk (xs ys : List N) : NT N

section GEC

variable {N T : Type}

/-- The symbol `Z_k` for a block. -/
def blkSym (rhs : List N) (A : N) (b : List Nat × List Nat) : NT N ⊕ T :=
  if b.1.length = 1 then .inl (.e (sym rhs A (b.1.headD 0)))
  else .inl (.blk (b.1.map (sym rhs A)) (b.2.map (sym rhs A)))

/-- The two rules of a non-singleton block. -/
def blkRules (rhs : List N) (A : N) (b : List Nat × List Nat) :
    List (NT N × List (NT N ⊕ T)) :=
  if b.1.length = 1 then []
  else
    [(.blk (b.1.map (sym rhs A)) (b.2.map (sym rhs A)),
        (b.1.map (sym rhs A)).map fun X => .inl (.l1 X)),
     (.blk (b.1.map (sym rhs A)) (b.2.map (sym rhs A)),
        (b.2.map (sym rhs A)).map fun X => .inl (.l2 X))]

/-- The rules of `G_EC` contributed by one rule of the pair. -/
noncomputable def rulesOf : PRule N T → List (NT N × List (NT N ⊕ T))
  | .lex A a b => [(.l1 A, [.inr a]), (.l2 A, [.inr b]), (.e A, [.inr a]), (.e A, [.inr b])]
  | .struct A rhs π =>
    (.l1 A, (List.range rhs.length).map fun i => .inl (.l1 (sym rhs A i))) ::
    (.l2 A, π.map fun i => .inl (.l2 (sym rhs A i))) ::
    (.e A, (blocksOf rhs.length π).map (blkSym rhs A)) ::
    (blocksOf rhs.length π).flatMap (blkRules rhs A)

/-- The grammar `G_EC`. -/
noncomputable def gec (P : List (PRule N T)) (S : N) : CFG (NT N) T :=
  ⟨.e S, P.flatMap rulesOf⟩

/-! ## `L_EC ⊆ L(G_EC)` -/

theorem gec_gen_of_tree (P : List (PRule N T)) (S : N) (hW : WFG P) (t : DTree N T) :
    t.Valid P →
      (gec P S).Gen [.inl (.l1 t.root)] t.skel.y1 ∧
      (gec P S).Gen [.inl (.l2 t.root)] t.skel.y2 ∧
      ∀ s, t.skel.Gram s → (gec P S).Gen [.inl (.e t.root)] s := by
  induction t with
  | leaf A a b =>
    intro hv
    have hmem : ∀ x, x ∈ rulesOf (PRule.lex A a b) → x ∈ (gec P S).rules :=
      fun x hx => List.mem_flatMap.mpr ⟨_, hv, hx⟩
    refine ⟨?_, ?_, ?_⟩
    · exact CFG.Gen.single (hmem _ (by simp [rulesOf, DTree.root])) (.term .nil)
    · exact CFG.Gen.single (hmem _ (by simp [rulesOf, DTree.root])) (.term .nil)
    · intro s hs
      rcases hs with rfl | rfl
      · exact CFG.Gen.single (hmem _ (by simp [rulesOf, DTree.root])) (.term .nil)
      · exact CFG.Gen.single (hmem _ (by simp [rulesOf, DTree.root])) (.term .nil)
  | node A rhs π cs ih =>
    intro hv
    obtain ⟨hr, hc⟩ := hv
    have hw := hW _ hr
    have hB := blocksOf_spec hw.2
    have hmem : ∀ x, x ∈ rulesOf (PRule.struct A rhs π) → x ∈ (gec P S).rules :=
      fun x hx => List.mem_flatMap.mpr ⟨_, hr, hx⟩
    have hsym : ∀ i, i < rhs.length → sym rhs A i = (cs i).root := fun i hi => by
      have h1 := sym_eq rhs A hi
      rw [(hc i hi).1] at h1
      exact (Option.some.inj h1).symm
    have hπ : ∀ i, i ∈ π → i < rhs.length := fun i hi => List.mem_range.mp (hw.2.mem_iff.mp hi)
    have g1 : ∀ K : List Nat, (∀ i, i ∈ K → i < rhs.length) →
        (gec P S).Gen (K.map fun i => .inl (.l1 (sym rhs A i)))
          (K.flatMap fun i => (cs i).skel.y1) := fun K hK =>
      CFG.Gen.map_flatMap K (fun i hi => by rw [hsym i (hK i hi)]; exact (ih i (hc i (hK i hi)).2).1)
    have g2 : ∀ K : List Nat, (∀ i, i ∈ K → i < rhs.length) →
        (gec P S).Gen (K.map fun i => .inl (.l2 (sym rhs A i)))
          (K.flatMap fun i => (cs i).skel.y2) := fun K hK =>
      CFG.Gen.map_flatMap K (fun i hi => by rw [hsym i (hK i hi)]; exact (ih i (hc i (hK i hi)).2).2.1)
    refine ⟨?_, ?_, ?_⟩
    · exact CFG.Gen.single (hmem _ (by simp [rulesOf, DTree.root])) (g1 _ (fun i hi => List.mem_range.mp hi))
    · exact CFG.Gen.single (hmem _ (by simp [rulesOf, DTree.root])) (g2 _ hπ)
    · intro s hs
      simp only [DTree.skel, Tree.Gram] at hs
      obtain ⟨zs, rfl, h⟩ := hs
      refine CFG.Gen.single (hmem (.e A, (blocksOf rhs.length π).map (blkSym rhs A))
        (by simp [rulesOf])) (CFG.Gen.of_all2 (h.imp_mem (fun b zk hb hp => ?_)))
      have hb1 : ∀ i, i ∈ b.1 → i < rhs.length :=
        fun i hi => List.mem_range.mp (hB.mem_left hb hi)
      have hb2 : ∀ i, i ∈ b.2 → i < rhs.length :=
        fun i hi => hb1 i ((hB.2.2 b hb).2.1.mem_iff.mpr hi)
      rcases hp with ⟨i, hi, hg⟩ | ⟨h2, hz⟩
      · have hi' : i < rhs.length := hb1 i (by rw [hi]; exact List.mem_cons_self)
        have : (blkSym rhs A b : NT N ⊕ T) = .inl (.e (cs i).root) := by
          simp [blkSym, hi, hsym i hi']
        rw [this]
        exact (ih i (hc i hi').2).2.2 zk hg
      · have hne : ¬ b.1.length = 1 := by omega
        have hs : (blkSym rhs A b : NT N ⊕ T) =
            .inl (.blk (b.1.map (sym rhs A)) (b.2.map (sym rhs A))) := by
          simp [blkSym, hne]
        have hin : ∀ x, x ∈ blkRules (T := T) rhs A b → x ∈ (gec P S).rules := fun x hx =>
          hmem x (by
            simp only [rulesOf, List.mem_cons]
            exact .inr (.inr (.inr (List.mem_flatMap.mpr ⟨b, hb, hx⟩))))
        rw [hs]
        rcases hz with rfl | rfl
        · refine CFG.Gen.single (hin (_, (b.1.map (sym rhs A)).map fun X => .inl (.l1 X))
            (by simp [blkRules, hne])) ?_
          rw [List.map_map]
          exact g1 _ hb1
        · refine CFG.Gen.single (hin (_, (b.2.map (sym rhs A)).map fun X => .inl (.l2 X))
            (by simp [blkRules, hne])) ?_
          rw [List.map_map]
          exact g2 _ hb2

/-- `L_EC ⊆ L(G_EC)`. -/
theorem gec_complete (P : List (PRule N T)) (S : N) (hW : WFG P) (s : List T) :
    LEC P S s → (gec P S).Language s := by
  rintro ⟨t, hv, rfl, hr⟩
  have hG := (main_theorem_EP t.skel (DTree.skel_wf hW t hv) [] s).mp hr
  exact (gec_gen_of_tree P t.root hW t hv).2.2 s hG

end GEC

/-! ## `L(G_EC) ⊆ L_EC` -/

/-- Gluing: if every block has trees for its own children, there is one family of
children that serves all blocks, because the blocks use disjoint sets of children. -/
theorem glue {B S Tr : Type} (idx : B → List Nat) (Q : B → (Nat → Tr) → S → Prop)
    (hQ : ∀ b c c' s, (∀ i, i ∈ idx b → c i = c' i) → Q b c s → Q b c' s) (d : Nat → Tr) :
    ∀ (bs : List B) (ss : List S), (bs.flatMap idx).Nodup →
      All2 (fun b s => ∃ c, Q b c s) bs ss → ∃ c, All2 (fun b s => Q b c s) bs ss := by
  intro bs
  induction bs with
  | nil =>
    intro ss _ h
    cases h
    exact ⟨d, .nil⟩
  | cons b bs ih =>
    intro ss hn h
    cases h with
    | @cons _ s _ ss' hb ht =>
      rw [List.flatMap_cons] at hn
      obtain ⟨_, hn2, hdisj⟩ := List.nodup_append.mp hn
      obtain ⟨c₁, hc₁⟩ := hb
      obtain ⟨c₂, hc₂⟩ := ih ss' hn2 ht
      refine ⟨fun i => if i ∈ idx b then c₁ i else c₂ i, .cons ?_ ?_⟩
      · exact hQ b c₁ _ s (fun i hi => by simp [hi]) hc₁
      · refine hc₂.imp_mem (fun b' s' hb' hq => hQ b' c₂ _ s' (fun i hi => ?_) hq)
        have hni : ¬ i ∈ idx b :=
          fun hi' => hdisj i hi' i (List.mem_flatMap.mpr ⟨b', hb', hi⟩) rfl
        simp [hni]

theorem glue' {B S Tr : Type} (idx : B → List Nat) (Q : B → (Nat → Tr) → S → Prop)
    (hQ : ∀ b c c' s, (∀ i, i ∈ idx b → c i = c' i) → Q b c s → Q b c' s)
    (bs : List B) (ss : List S) (hne : bs ≠ []) (hn : (bs.flatMap idx).Nodup)
    (h : All2 (fun b s => ∃ c, Q b c s) bs ss) : ∃ c, All2 (fun b s => Q b c s) bs ss := by
  cases h with
  | nil => exact absurd rfl hne
  | cons hb ht =>
    obtain ⟨c, hc⟩ := hb
    exact glue idx Q hQ c _ _ hn (.cons ⟨c, hc⟩ ht)

theorem nodup_of_mem_flatten {α : Type} {L : List (List α)} (h : L.flatten.Nodup)
    {l : List α} (hl : l ∈ L) : l.Nodup := by
  induction L with
  | nil => cases hl
  | cons a L ih =>
    rw [List.flatten_cons] at h
    obtain ⟨h1, h2, _⟩ := List.nodup_append.mp h
    rcases List.mem_cons.mp hl with rfl | hl
    · exact h1
    · exact ih h2 hl

theorem flatMap_congr' {α : Type} {f g : Nat → List α} :
    ∀ (K : List Nat), (∀ i, i ∈ K → f i = g i) → K.flatMap f = K.flatMap g := by
  intro K
  induction K with
  | nil => intro _; rfl
  | cons k K ih =>
    intro h
    rw [List.flatMap_cons, List.flatMap_cons, h k List.mem_cons_self,
      ih (fun i hi => h i (List.mem_cons_of_mem _ hi))]

section Sound

variable {N T : Type}

/-- From a tree for each index of `K` (with a prescribed sentence), a family of
children. -/
theorem trees_of_all2 (P : List (PRule N T)) (rhs : List N) (A : N) (y : Tree T → List T)
    (K : List Nat) (hK : K.Nodup) (hne : K ≠ []) (ss : List (List T))
    (h : All2 (fun i sk => ∃ t : DTree N T, t.Valid P ∧ t.root = sym rhs A i ∧ sk = y t.skel)
      K ss) :
    ∃ c : Nat → DTree N T, (∀ i, i ∈ K → (c i).Valid P ∧ (c i).root = sym rhs A i) ∧
      ss.flatten = K.flatMap (fun i => y (c i).skel) := by
  have hn : (K.flatMap fun i => [i]).Nodup := by
    have e : (K.flatMap fun i => [i]) = K := by
      clear hK hne h
      induction K with
      | nil => rfl
      | cons k K ih => rw [List.flatMap_cons, ih]; rfl
    rw [e]; exact hK
  obtain ⟨c, hc⟩ := glue' (fun i => [i])
    (fun i (c : Nat → DTree N T) sk => (c i).Valid P ∧ (c i).root = sym rhs A i ∧ sk = y (c i).skel)
    (fun i c c' s hcc hq => by
      have := hcc i List.mem_cons_self
      rw [← this]; exact hq)
    K ss hne hn (h.imp (fun i sk ⟨t, ht⟩ => ⟨fun _ => t, ht⟩))
  refine ⟨c, fun i hi => ?_, ?_⟩
  · obtain ⟨_, h1, h2, _⟩ := hc.exists_of_mem i hi
    exact ⟨h1, h2⟩
  · have := All2.eq_map (g := fun i => y (c i).skel) (hc.imp (fun i sk hq => hq.2.2))
    rw [this, List.flatMap_def]

/-- What each symbol of `G_EC` means. -/
def Sem (P : List (PRule N T)) : NT N ⊕ T → List T → Prop
  | .inr a, s => s = [a]
  | .inl (.l1 A), s => ∃ t : DTree N T, t.Valid P ∧ t.root = A ∧ s = t.skel.y1
  | .inl (.l2 A), s => ∃ t : DTree N T, t.Valid P ∧ t.root = A ∧ s = t.skel.y2
  | .inl (.e A), s => ∃ t : DTree N T, t.Valid P ∧ t.root = A ∧ t.skel.Gram s
  | .inl (.blk xs ys), s =>
    (∃ ss : List (List T), s = ss.flatten ∧
      All2 (fun X sk => ∃ t : DTree N T, t.Valid P ∧ t.root = X ∧ sk = t.skel.y1) xs ss) ∨
    (∃ ss : List (List T), s = ss.flatten ∧
      All2 (fun X sk => ∃ t : DTree N T, t.Valid P ∧ t.root = X ∧ sk = t.skel.y2) ys ss)

/-- What a block contributes, for a given family of children `c`. -/
def BlockSem (P : List (PRule N T)) (rhs : List N) (A : N) (b : List Nat × List Nat)
    (c : Nat → DTree N T) (sk : List T) : Prop :=
  b.1.Perm b.2 ∧ (∀ i, i ∈ b.1 → (c i).Valid P ∧ (c i).root = sym rhs A i) ∧
    Piece (fun i zk => (c i).skel.Gram zk) (fun K => K.flatMap fun i => (c i).skel.y1)
      (fun K => K.flatMap fun i => (c i).skel.y2) b sk

theorem BlockSem.congr (P : List (PRule N T)) (rhs : List N) (A : N)
    (b : List Nat × List Nat) (c c' : Nat → DTree N T) (sk : List T)
    (hcc : ∀ i, i ∈ b.1 → c i = c' i) : BlockSem P rhs A b c sk → BlockSem P rhs A b c' sk := by
  rintro ⟨hp, hv, hpiece⟩
  refine ⟨hp, fun i hi => by rw [← hcc i hi]; exact hv i hi, ?_⟩
  refine Piece.imp (fun i hi => by rw [hcc i hi]; exact id) ?_ ?_ hpiece
  · exact flatMap_congr' _ (fun i hi => by rw [hcc i hi])
  · exact flatMap_congr' _ (fun i hi => by rw [hcc i (hp.mem_iff.mpr hi)])

/-- One rule of `G_EC` is sound for `Sem`. -/
theorem sem_rule (P : List (PRule N T)) (S : N) (hW : WFG P) {X : NT N}
    {β : List (NT N ⊕ T)} {ss : List (List T)} (hmem : (X, β) ∈ (gec P S).rules)
    (h : All2 (Sem P) β ss) : Sem P (.inl X) ss.flatten := by
  obtain ⟨r, hr, hx⟩ := List.mem_flatMap.mp hmem
  cases r with
  | lex A a b =>
    simp only [rulesOf, List.mem_cons, Prod.mk.injEq, List.not_mem_nil, or_false] at hx
    have one : ∀ {w : T} {ss : List (List T)}, All2 (Sem P) [.inr w] ss → ss.flatten = [w] := by
      intro w ss h
      cases h with
      | cons hab ht =>
        cases ht
        simp only [Sem] at hab
        simp [hab]
    rcases hx with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
    · exact ⟨.leaf A a b, hr, rfl, one h⟩
    · exact ⟨.leaf A a b, hr, rfl, one h⟩
    · exact ⟨.leaf A a b, hr, rfl, .inl (one h)⟩
    · exact ⟨.leaf A a b, hr, rfl, .inr (one h)⟩
  | struct A rhs π =>
    have hw := hW _ hr
    have hm : 0 < rhs.length := List.length_pos_iff.mpr hw.1
    have hB := blocksOf_spec hw.2
    have hrn : List.range rhs.length ≠ [] := by
      intro h0
      have := congrArg List.length h0
      rw [List.length_range, List.length_nil] at this
      omega
    have hroot : ∀ (c : Nat → DTree N T) i, i < rhs.length → (c i).root = sym rhs A i →
        rhs[i]? = some (c i).root := fun c i hi h => by rw [h]; exact sym_eq rhs A hi
    simp only [rulesOf, List.mem_cons, Prod.mk.injEq] at hx
    rcases hx with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩ | hx
    · -- A¹ → X₀¹ ⋯
      rw [All2.map_left] at h
      obtain ⟨c, hc, hfl⟩ := trees_of_all2 P rhs A Tree.y1 _ List.nodup_range hrn ss h
      exact ⟨.node A rhs π c,
        ⟨hr, fun i hi => ⟨hroot c i hi (hc i (List.mem_range.mpr hi)).2,
          (hc i (List.mem_range.mpr hi)).1⟩⟩, rfl, hfl⟩
    · -- A² → X_{π 0}² ⋯
      rw [All2.map_left] at h
      have hπn : π.Nodup := hw.2.nodup_iff.mpr List.nodup_range
      have hπne : π ≠ [] := fun h0 => hrn (by rw [h0] at hw; exact hw.2.nil_eq.symm)
      obtain ⟨c, hc, hfl⟩ := trees_of_all2 P rhs A Tree.y2 _ hπn hπne ss h
      have hin : ∀ i, i < rhs.length → i ∈ π :=
        fun i hi => hw.2.mem_iff.mpr (List.mem_range.mpr hi)
      exact ⟨.node A rhs π c,
        ⟨hr, fun i hi => ⟨hroot c i hi (hc i (hin i hi)).2, (hc i (hin i hi)).1⟩⟩, rfl, hfl⟩
    · -- Aᴱ → Z₁ ⋯ Z_q
      rw [All2.map_left] at h
      have hbsn : ((blocksOf rhs.length π).flatMap Prod.fst).Nodup := by
        rw [List.flatMap_def, ← hB.1]; exact List.nodup_range
      have hbsne : blocksOf rhs.length π ≠ [] := by
        intro h0
        have := hB.1
        rw [h0] at this
        exact hrn this
      have step : All2 (fun b sk => ∃ c, BlockSem P rhs A b c sk) (blocksOf rhs.length π) ss := by
        refine h.imp_mem (fun b sk hb hs => ?_)
        have hirr := hB.2.2 b hb
        have hbn : b.1.Nodup := by
          refine nodup_of_mem_flatten (L := (blocksOf rhs.length π).map Prod.fst) ?_
            (List.mem_map.mpr ⟨b, hb, rfl⟩)
          rw [← hB.1]; exact List.nodup_range
        by_cases h1 : b.1.length = 1
        · obtain ⟨i, hi⟩ := List.length_eq_one_iff.mp h1
          simp only [blkSym, hi, List.length_cons, List.length_nil, List.headD_cons, ite_true,
            Sem] at hs
          obtain ⟨t, hv, hroot', hg⟩ := hs
          refine ⟨fun _ => t, hirr.2.1, fun j hj => ?_, .inl ⟨i, hi, hg⟩⟩
          rw [hi] at hj
          rw [List.mem_singleton.mp hj]
          exact ⟨hv, hroot'⟩
        · have h2 : 2 ≤ b.1.length := by
            have := List.length_pos_iff.mpr hirr.1
            omega
          simp only [blkSym, h1, ite_false, Sem] at hs
          rcases hs with ⟨ss', rfl, hs⟩ | ⟨ss', rfl, hs⟩
          · rw [All2.map_left] at hs
            obtain ⟨c, hc, hfl⟩ := trees_of_all2 P rhs A Tree.y1 _ hbn hirr.1 ss' hs
            exact ⟨c, hirr.2.1, hc, .inr ⟨h2, .inl hfl⟩⟩
          · rw [All2.map_left] at hs
            have hb2n : b.2.Nodup := hirr.2.1.nodup_iff.mp hbn
            have hb2ne : b.2 ≠ [] := fun h0 => hirr.1 (by
              have := hirr.2.1; rw [h0] at this; exact this.eq_nil)
            obtain ⟨c, hc, hfl⟩ := trees_of_all2 P rhs A Tree.y2 _ hb2n hb2ne ss' hs
            exact ⟨c, hirr.2.1, fun i hi => hc i (hirr.2.1.mem_iff.mp hi), .inr ⟨h2, .inr hfl⟩⟩
      obtain ⟨c, hc⟩ := glue' Prod.fst (BlockSem P rhs A) (BlockSem.congr P rhs A)
        _ ss hbsne hbsn step
      have hval : ∀ i, i < rhs.length → (c i).Valid P ∧ (c i).root = sym rhs A i := by
        intro i hi
        have hi' : i ∈ List.range rhs.length := List.mem_range.mpr hi
        rw [hB.1] at hi'
        obtain ⟨l, hl, hil⟩ := List.mem_flatten.mp hi'
        obtain ⟨b, hb, rfl⟩ := List.mem_map.mp hl
        obtain ⟨_, _, hv, _⟩ := hc.exists_of_mem b hb
        exact hv i hil
      refine ⟨.node A rhs π c,
        ⟨hr, fun i hi => ⟨hroot c i hi (hval i hi).2, (hval i hi).1⟩⟩, rfl, ?_⟩
      simp only [DTree.skel, Tree.Gram]
      exact ⟨ss, rfl, hc.imp (fun b sk hq => hq.2.2)⟩
    · -- the two rules of a non-singleton block
      obtain ⟨b, hb, hx⟩ := List.mem_flatMap.mp hx
      by_cases h1 : b.1.length = 1
      · simp [blkRules, h1] at hx
      · simp only [blkRules, h1, ite_false, List.mem_cons, Prod.mk.injEq, List.not_mem_nil,
          or_false] at hx
        rcases hx with ⟨rfl, rfl⟩ | ⟨rfl, rfl⟩
        · rw [All2.map_left] at h
          exact .inl ⟨ss, rfl, h⟩
        · rw [All2.map_left] at h
          exact .inr ⟨ss, rfl, h⟩

/-- Every derivation of `G_EC` is sound for `Sem`. -/
theorem gen_sem (P : List (PRule N T)) (S : N) (hW : WFG P) {α : List (NT N ⊕ T)}
    {s : List T} (h : (gec P S).Gen α s) : ∃ ss, s = ss.flatten ∧ All2 (Sem P) α ss := by
  induction h with
  | nil => exact ⟨[], rfl, .nil⟩
  | @term a α s _ ih =>
    obtain ⟨ss, rfl, hss⟩ := ih
    exact ⟨[a] :: ss, rfl, .cons rfl hss⟩
  | @rule X β α s₁ s₂ hmem _ _ ihβ ihα =>
    obtain ⟨ss₁, rfl, h₁⟩ := ihβ
    obtain ⟨ss₂, rfl, h₂⟩ := ihα
    exact ⟨ss₁.flatten :: ss₂, rfl, .cons (sem_rule P S hW hmem h₁) h₂⟩

theorem gen_sem_single (P : List (PRule N T)) (S : N) (hW : WFG P) {X : NT N ⊕ T}
    {s : List T} (h : (gec P S).Gen [X] s) : Sem P X s := by
  obtain ⟨ss, rfl, hss⟩ := gen_sem P S hW h
  cases hss with
  | cons hab ht =>
    cases ht
    simpa using hab

/-- `L(G_EC) ⊆ L_EC`. -/
theorem gec_sound (P : List (PRule N T)) (S : N) (hW : WFG P) (s : List T) :
    (gec P S).Language s → LEC P S s := by
  intro h
  obtain ⟨t, hv, hroot, hg⟩ := gen_sem_single P S hW h
  exact ⟨t, hv, hroot, (main_theorem_EP t.skel (DTree.skel_wf hW t hv) [] s).mpr hg⟩

/-- **Theorem 1.**  The grammar `G_EC` generates exactly `L_EC`. -/
theorem gec_correct (P : List (PRule N T)) (S : N) (s : List T) :
    WFG P → ((gec P S).Language s ↔ LEC P S s) :=
  fun hW => ⟨gec_sound P S hW s, gec_complete P S hW s⟩

/-- `L_EC` is context-free. -/
theorem LEC_contextFree (P : List (PRule N T)) (S : N) :
    WFG P → ∃ G : CFG (NT N) T, ∀ s, (G.Language s ↔ LEC P S s) :=
  fun hW => ⟨gec P S, fun s => gec_correct P S s hW⟩

/-! ## The monolingual languages are contained in `L_EC` -/

theorem lang1_lift (P : List (PRule N T)) (S S' : N) {α : List (N ⊕ T)} {s : List T}
    (h : (lang1 P S').Gen α s) : (gec P S).Gen (α.map (Sum.map NT.l1 id)) s := by
  induction h with
  | nil => exact .nil
  | term _ ih => exact .term ih
  | @rule A β α s₁ s₂ hm _ _ ihβ ihα =>
    refine .rule ?_ ihβ ihα
    obtain ⟨r, hr, hx⟩ := List.mem_map.mp hm
    refine List.mem_flatMap.mpr ⟨r, hr, ?_⟩
    cases r with
    | lex B a b =>
      injection hx with h1 h2
      subst h1; subst h2
      simp [rulesOf]
    | struct B rhs π =>
      injection hx with h1 h2
      subst h1; subst h2
      simp only [rulesOf, List.mem_cons]
      refine .inl ?_
      rw [List.map_map, map_sym rhs B (fun X => (Sum.inl (NT.l1 X) : NT N ⊕ T))]
      rfl

theorem lang2_lift (P : List (PRule N T)) (S S' : N) {α : List (N ⊕ T)} {s : List T}
    (h : (lang2 P S').Gen α s) : (gec P S).Gen (α.map (Sum.map NT.l2 id)) s := by
  induction h with
  | nil => exact .nil
  | term _ ih => exact .term ih
  | @rule A β α s₁ s₂ hm _ _ ihβ ihα =>
    refine .rule ?_ ihβ ihα
    obtain ⟨r, hr, hx⟩ := List.mem_map.mp hm
    refine List.mem_flatMap.mpr ⟨r, hr, ?_⟩
    cases r with
    | lex B a b =>
      injection hx with h1 h2
      subst h1; subst h2
      simp [rulesOf]
    | struct B rhs π =>
      injection hx with h1 h2
      subst h1; subst h2
      simp only [rulesOf, List.mem_cons]
      refine .inr (.inl ?_)
      rw [List.map_map]
      rfl

/-- `L(G_1) ∪ L(G_2) ⊆ L_EC`. -/
theorem mono_subset (P : List (PRule N T)) (S : N) (hW : WFG P) (s : List T) :
    (lang1 P S).Language s ∨ (lang2 P S).Language s → LEC P S s := by
  rintro (h | h)
  · obtain ⟨t, hv, hroot, rfl⟩ := gen_sem_single P S hW (lang1_lift P S S h)
    have hwf := DTree.skel_wf hW t hv
    refine ⟨t, hv, hroot, (realEP_iff_real (Tree.lin1_nodup _ hwf _) (Tree.lin_perm _ hwf _) _).mpr ?_⟩
    rw [← Tree.lin1_map t.skel []]
    exact Real.mono1 (Tree.lin_perm _ hwf _)
  · obtain ⟨t, hv, hroot, rfl⟩ := gen_sem_single P S hW (lang2_lift P S S h)
    have hwf := DTree.skel_wf hW t hv
    refine ⟨t, hv, hroot, (realEP_iff_real (Tree.lin1_nodup _ hwf _) (Tree.lin_perm _ hwf _) _).mpr ?_⟩
    rw [← Tree.lin2_map t.skel []]
    exact Real.mono2 (Tree.lin_perm _ hwf _)

end Sound

/-! ## A sanity check of the definitions

One rule `S → X X` with the same order in both languages, one lexical pair `X → a / b`.
Both mixed sentences `a b` and `b a` are in `L_EC`, by the literal definition. -/

example : LEC [PRule.struct 0 [1, 1] [0, 1], PRule.lex 1 "a" "b"] 0 ["a", "b"] := by
  refine ⟨.node 0 [1, 1] [0, 1] (fun _ => .leaf 1 "a" "b"), ?_, rfl, rfl, ?_⟩
  · refine ⟨by simp, fun i hi => ⟨?_, by simp [DTree.Valid]⟩⟩
    have : i = 0 ∨ i = 1 := by simp at hi; omega
    rcases this with rfl | rfl <;> rfl
  · have e1 : ∀ j, EqPt (DTree.node 0 [1, 1] [0, 1] (fun _ => .leaf 1 "a" "b")).lin1
        (DTree.node (N := Nat) 0 [1, 1] [0, 1] (fun _ => .leaf 1 "a" "b")).lin2 j ↔ j ≤ 2 :=
      fun j => ⟨fun h => h.1, fun h => ⟨h, fun _ => Iff.rfl⟩⟩
    refine RealFrom.seg1 (j := 0) (j' := 1) (by decide) ((e1 1).mpr (by decide))
      (fun k h1 h2 => by omega) ?_
    refine RealFrom.seg2 (j := 1) (j' := 2) (z := []) (by decide) ((e1 2).mpr (by decide))
      (fun k h1 h2 => by omega) ?_
    exact .done rfl

/-! ## Axioms -/

#print axioms gec_correct
#print axioms LEC_contextFree
#print axioms mono_subset
#print axioms swapClause_gram
#print axioms main_theorem_EP
#print axioms realEP_iff_real
